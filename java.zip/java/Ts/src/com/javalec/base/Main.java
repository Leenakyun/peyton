package com.javalec.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		// 선언문
		
				Scanner scanner = new Scanner(System.in);
				int scr = 0;
				
				System.out.print("점수를 입력 하세요 :");
				
				String message = "";
				
				scr = scanner.nextInt();		
				 
				
				
				
				
				
				
				// 입력값 
				
				switch(scr / 10) {
				case 10:                          // 밑의 값과 동일하다면 case의 알고리즘만 적는다. 
				case 9:                           // if문을 통과해야만 switch 와 변환이 가능하다. 서로 소스에 포함되어도 상관없다. 
					message = ("A학점");
					break;
				case 8: 
					message = ("B학점");
					break;
				case 7: 
					message = ("C학점");
					break;
				case 6: 
					message = ("D학점");
					break;
				default : 
					message = ("F학점");
					break;
				}
				
				
				
				
				
				// 출력값 
				
				System.out.println("점수가 " + scr + "여서" + message + "입니다.");
		
		
		
		
		
		
		
	}

}
