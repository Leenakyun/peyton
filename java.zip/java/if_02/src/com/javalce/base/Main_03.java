package com.javalce.base;

import java.util.Scanner;

public class Main_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner scanner = new Scanner(System.in);
		int pey = 0;
		
		String message = "";
		
		if(pey % 2) {
			message = "입력하신 숫자", (pey) ,"(은)는 짝수 입니다.";
		}else {
			message = "";
		}
		
		
		
		
		
	}

}
