package com.javalce.base;

import java.util.Scanner;

public class Maing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * 실행 화면)
		 * BMI 계산기
		 *
		 * 신장(cm)을 입력하세요 : 170
		 * 몸무게(kg)을 입력하세요 : 70
		 * 
		 * 계산 결과 귀하는 __입니다.
		 */
		
		
		// 선언문 
		
		Scanner scanner = new Scanner(System.in);
		double cm = 0, kg = 0;
		
		
		System.out.println("신장(cm)을 입력하세요 :");
		cm = scanner.nextInt();
		
		System.out.println("몸무게(kg)을 입력하세요 :");
		kg = scanner.nextInt();
		
		
		
		double avg = kg / (cm * cm);
		String message = "";
		
		
		// 입력문 
		
		
		
		
		
		if(avg >= 0 || avg < 18.5) {
			message = "저체중";
		}else if(avg >= 18.5 || avg < 23.0) {
			message = "정상체중";
		}else if(avg >= 23 || avg < 25.0) {
			message = "과체중";
		}else if(avg >= 25.0 || avg < 30.0) {
			message = "비만";
		}else {
			message = "고도비만";
		}
		
		
		
		
		
		// 출력문
		
		System.out.println("계산 결과 귀하는 " + message + "입니다.");
		
		
		
		
		
		
	}

}
