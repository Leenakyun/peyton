SELECT * FROM useraddress.userinfo;
select seqno, name, telno, relation from userinfo;