package com.javalec.base;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Main_01 extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JTextField tfName;
	private JTextField tfTelno;
	private JLabel lblNewLabel_1;
	private JTextField tfAddress;
	private JLabel lblNewLabel_2;
	private JTextField tfEmail;
	private JLabel lblNewLabel_3;
	private JTextField tfRelation;
	private JLabel lblNewLabel_4;
	private JButton btnNewButton;

	// Database 
	
	private final String url_mysql = "jdbc:mysql://127.0.0.1/useraddress?serverTimezone=UTC&characterEncoding=utf8&useSSL=FALSE" ;
	private final String id_mysql = "root" ;
	private final String pw_mysql = "qwer1234"; 
	
	
	
	
	
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main_01 frame = new Main_01();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main_01() {
		setTitle("주소록 등록");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblNewLabel());
		contentPane.add(getTfName());
		contentPane.add(getTfTelno());
		contentPane.add(getLblNewLabel_1());
		contentPane.add(getTfAddress());
		contentPane.add(getLblNewLabel_2());
		contentPane.add(getTfEmail());
		contentPane.add(getLblNewLabel_3());
		contentPane.add(getTfRelation());
		contentPane.add(getLblNewLabel_4());
		contentPane.add(getBtnNewButton());
	}

	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("성명 :");
			lblNewLabel.setBounds(51, 61, 61, 16);
		}
		return lblNewLabel;
	}
	private JTextField getTfName() {
		if (tfName == null) {
			tfName = new JTextField();
			tfName.setBounds(153, 56, 130, 26);
			tfName.setColumns(10);
		}
		return tfName;
	}
	private JTextField getTfTelno() {
		if (tfTelno == null) {
			tfTelno = new JTextField();
			tfTelno.setColumns(10);
			tfTelno.setBounds(153, 102, 170, 26);
		}
		return tfTelno;
	}
	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("전화번호 :");
			lblNewLabel_1.setBounds(51, 107, 61, 16);
		}
		return lblNewLabel_1;
	}
	private JTextField getTfAddress() {
		if (tfAddress == null) {
			tfAddress = new JTextField();
			tfAddress.setColumns(10);
			tfAddress.setBounds(153, 150, 170, 26);
		}
		return tfAddress;
	}
	private JLabel getLblNewLabel_2() {
		if (lblNewLabel_2 == null) {
			lblNewLabel_2 = new JLabel("주소 :");
			lblNewLabel_2.setBounds(51, 155, 61, 16);
		}
		return lblNewLabel_2;
	}
	private JTextField getTfEmail() {
		if (tfEmail == null) {
			tfEmail = new JTextField();
			tfEmail.setColumns(10);
			tfEmail.setBounds(153, 198, 170, 26);
		}
		return tfEmail;
	}
	private JLabel getLblNewLabel_3() {
		if (lblNewLabel_3 == null) {
			lblNewLabel_3 = new JLabel("전자우편 :");
			lblNewLabel_3.setBounds(51, 203, 61, 16);
		}
		return lblNewLabel_3;
	}
	private JTextField getTfRelation() {
		if (tfRelation == null) {
			tfRelation = new JTextField();
			tfRelation.setColumns(10);
			tfRelation.setBounds(153, 245, 130, 26);
		}
		return tfRelation;
	}
	private JLabel getLblNewLabel_4() {
		if (lblNewLabel_4 == null) {
			lblNewLabel_4 = new JLabel("관계 :");
			lblNewLabel_4.setBounds(51, 250, 61, 16);
		}
		return lblNewLabel_4;
	}
	private JButton getBtnNewButton() {
		if (btnNewButton == null) {
			btnNewButton = new JButton("입력");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int i_chk = insertFieldCheck();
					if(i_chk == 0){
					insertAction();
				}else {
					JOptionPane.showMessageDialog(null, "데이터를 입력해주세요!");
				}
				}
			});
			btnNewButton.setBounds(302, 317, 117, 29);
		}
		return btnNewButton;
	}
	
	//------------------- function
	
	
	private int insertFieldCheck() { 		
		int i = 0; 
		String message = ""; 		// 사용자가 입력하지 않은 데이터가 뭔지 알려주기 위해 초기화.
		
		if (tfName.getText().trim().length() == 0) { 		// 이름의 길이가 0이다? 입력 안한거. trim은 꼭 해!!!!
			i++ ; 		// return 값이 0이 안되므로 인서트 못하고 에러남.
			message = "이름을 ";
			tfName.requestFocus(); 		// 이름이 틀리면 저 위치로 커서가 돌아가게 해줌.
		}
		if (tfTelno.getText().trim().length() == 0) {
			i++ ;
			message = "전화번호를 ";
			tfTelno.requestFocus();
		}
		
		if (tfAddress.getText().trim().length() == 0) {
			i++ ;
			message = "주소를 ";
			tfAddress.requestFocus();
		}
		
		if (tfEmail.getText().trim().length() == 0) {
			i++ ;
			message = "전자우편을 ";
			tfEmail.requestFocus();
		}
		
		if (tfRelation.getText().trim().length() == 0) {
			i++ ;
			message = "관계를 ";
			tfRelation.requestFocus();
		}
		
		// return 전에 사용자가 입력하지 않은 데이터가 뭔지 출력하게 해줘야 제대로 나감. return 하고 쓰면 말짱꽝ㅇ.야 
		if (i > 0) {
			JOptionPane.showMessageDialog(null,  message + "확인하세요!");
		}
		
		return i; 		// 아무 이상이 없으면 i==0 이므로 인서트 제대로 될것. 위 attribute 중에서 잘못 입력되거나 입력 안된 값이 있으면 i값이 0이 안되어서 에러남.
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	private void insertAction() { 		// 연결 버튼 눌렀을 때 1. 데이터 베이스와 연결. 2. insert into로 값 집어넣기. 
		PreparedStatement ps = null; 		// 라이브러리 - 자바 커넥터에 있는 내
		try {		// 일단 해본다. 이상이 생기면 catch로 가. 내 자바와 네트워크, 아이디, 패스워드 타고 DB 스키마 서버에 접근. 일단 정의만 해둔다.
			Class.forName("com.mysql.cj.jdbc.Driver"); 		//  어떤 클래스 쓸건지
			Connection conn_mysql = DriverManager.getConnection(url_mysql, id_mysql, pw_mysql);
			Statement stmt_mysql = conn_mysql.createStatement(); 		// 불러올 때 많이 사용
			
			// sql 문장 적어서 
			String query = "insert into userinfo (name, telno, address, email, relation)" ; 		// 서버에 접근해서 데이터 입력 
			String query1 = " values (?, ?, ?, ?, ?)" ; 		// values 앞에 안 띄고 시작하면 query와 query1이 합쳐질 때 띄어쓰기 안해서 sql에서 에러남. ? : 어떤 데이터가 들어갈지 모를때. -> 각 물음표 해결을 preparedStatement가 해줌.(?에 뭐가 들어갈거야.)
			
			ps = conn_mysql.prepareStatement(query + query1) ; 		// 위에서 선언한 내용들을 실행시킴. 여기서부터 실행이야!!!
			ps.setString(1, tfName.getText().trim()); 		// 처음 ? 값엔 이름 데이터를 스페이스바 제거하고(trim) 받아와.
			ps.setString(2, tfTelno.getText().trim()); 		// 두번째 ? 값엔 전화번호 데이터를 스페이스바 제거하고(trim) 받아와.
			ps.setString(3, tfAddress.getText().trim()); 		// 세번째 ? 값엔 주소 데이터를 스페이스바 제거하고(trim) 받아와.
			ps.setString(4, tfEmail.getText().trim()); 		// 네번째 ? 값엔 이메일 데이터를 스페이스바 제거하고(trim) 받아와.
			ps.setString(5, tfRelation.getText().trim()); 		// 다섯번째 ? 값엔 관계 데이터를 스페이스바 제거하고(trim) 받아와.
			
			ps.executeUpdate(); 		// 데이터 넣었으니까 실행하자. sql에 집어 넣어.   dele
			conn_mysql.close(); 		// 데이터 입력 후 빠져 나와라.
			
			JOptionPane.showMessageDialog(null, tfName.getText() + "님의 정보가 입력 되었습니다."); 		// 사용자가 입력 완료 후 버튼 눌렀을 때 보여줄 메시지.
			
		} catch (Exception e) {
			e.printStackTrace(); 		// 개발할때만 사용. 에러가 걸리면 캐치로 넘어와서 에러코드 보여줘. 출시할때는 저거 있으면 큰일나 해킹당함. 다이어로그같은거 띄워주면 됨 
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}// End

