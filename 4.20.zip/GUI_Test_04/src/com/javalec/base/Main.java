package com.javalec.base;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Main extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JTextField tfNum1;
	private JLabel lblNewLabel_1;
	private JTextField tfNum2;
	private JComboBox comboBox;
	private JLabel lbNum1;
	private JLabel lbNum2;
	private JLabel lbNum3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setTitle("전자우편 주소 결정");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 633, 221);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblNewLabel());
		contentPane.add(getTfNum1());
		contentPane.add(getLblNewLabel_1());
		contentPane.add(getTfNum2());
		contentPane.add(getComboBox());
		contentPane.add(getLbNum1());
		contentPane.add(getLbNum2());
		contentPane.add(getLbNum3());
	}

	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("Email주소 :");
			lblNewLabel.setBounds(28, 74, 77, 16);
		}
		return lblNewLabel;
	}
	private JTextField getTfNum1() {
		if (tfNum1 == null) {
			tfNum1 = new JTextField();
			tfNum1.setBounds(103, 69, 130, 26);
			tfNum1.setColumns(10);
		}
		return tfNum1;
	}
	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("@");
			lblNewLabel_1.setBounds(245, 74, 35, 16);
		}
		return lblNewLabel_1;
	}
	private JTextField getTfNum2() {
		if (tfNum2 == null) {
			tfNum2 = new JTextField();
			tfNum2.setEditable(false);
			tfNum2.setBounds(277, 69, 130, 26);
			tfNum2.setColumns(10);
		}
		return tfNum2;
	}
	private JComboBox getComboBox() {
		if (comboBox == null) {
			comboBox = new JComboBox();
			comboBox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					comboAction();
				}
			});
			comboBox.setModel(new DefaultComboBoxModel(new String[] {"naver.com", "daum.net", "gmail.com", "icloud.com"}));
			comboBox.setBounds(419, 70, 186, 27);
		}
		return comboBox;
		
		
		
	}
	
	//------ Function -------
	
	private void comboAction() {
		String str1 = comboBox.getSelectedItem().toString();
		tfNum2.setText(str1);
	}
	
	private void 
	
	
	
	
	
	
	
	
	
	
	
	private JLabel getLbNum1() {
		if (lbNum1 == null) {
			lbNum1 = new JLabel("당신의 이메일은");
			lbNum1.setBounds(129, 147, 90, 16);
		}
		return lbNum1;
	}
	private JLabel getLbNum2() {
		if (lbNum2 == null) {
			lbNum2 = new JLabel("New label");
			lbNum2.setBounds(227, 147, 208, 16);
		}
		return lbNum2;
	}
	private JLabel getLbNum3() {
		if (lbNum3 == null) {
			lbNum3 = new JLabel("입니다.");
			lbNum3.setBounds(447, 147, 47, 16);
		}
		return lbNum3;
	}
}// End
