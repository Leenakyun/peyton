package com.javalec.function;

public class Clac {

}
