package com.javalec.function;

public class Clac {

	
	
	
	
	
	
	
	public Clac() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
	
	
	
	
}
