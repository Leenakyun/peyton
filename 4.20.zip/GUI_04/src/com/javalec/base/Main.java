package com.javalec.base;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class Main extends JFrame {

	private JPanel contentPane;
	private JComboBox comboBox;
	private JTextField tfFruits;
	private JTextField tfAppend;
	private JButton btnAppend;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setTitle("Combo box");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getComboBox());
		contentPane.add(getTfFruits());
		contentPane.add(getTfAppend());
		contentPane.add(getBtnAppend());
	}
	private JComboBox getComboBox() {
		if (comboBox == null) {
			comboBox = new JComboBox();
			comboBox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					comboAction();
				}
			});
			comboBox.setModel(new DefaultComboBoxModel(new String[] {"Apple", "Banana", "Grape", "Mango", "Melon"}));
			comboBox.setBounds(39, 27, 130, 27);
		}
		return comboBox;
	}
	private JTextField getTfFruits() {
		if (tfFruits == null) {
			tfFruits = new JTextField();
			tfFruits.setBounds(222, 26, 130, 26);
			tfFruits.setColumns(10);
		}
		return tfFruits;
	}
	
	//--------- Function ----------
	
	private void comboAction() {
		String strFruit = comboBox.getSelectedItem().toString();
		tfFruits.setText(strFruit);
	}
	
	
	
	
	
	private void appendAction() {
		String str = tfFruits.getText();
		comboBox.addItem(str);
	}
	
	
	
	
	
	
	
	private JTextField getTfAppend() {
		if (tfAppend == null) {
			tfAppend = new JTextField();
			tfAppend.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					appendAction();
				}
			});
			tfAppend.setBounds(39, 120, 130, 26);
			tfAppend.setColumns(10);
		}
		return tfAppend;
	}
	private JButton getBtnAppend() {
		if (btnAppend == null) {
			btnAppend = new JButton("Add");
			btnAppend.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					appendAction();
				}
			});
			btnAppend.setBounds(181, 120, 53, 29);
		}
		return btnAppend;
	}
}// End
