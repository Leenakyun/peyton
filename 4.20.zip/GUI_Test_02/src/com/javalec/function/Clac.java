package com.javalec.function;

public class Clac {

	int num1;
	int num2;
	int sum;
	int stratNum;
	int endNum;
	
	
	
	public Clac() {
		// TODO Auto-generated constructor stub
	}

	
	
	public Clac(int num1, int num2, int sum, int stratNum, int endNum) {
		super();
		this.num1 = num1;
		this.num2 = num2;
		this.sum = sum;
		this.stratNum = stratNum;
		this.endNum = endNum;
	}






	public void addition() {
		for(int i = stratNum; i <= endNum; i++) {
			sum += i;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
