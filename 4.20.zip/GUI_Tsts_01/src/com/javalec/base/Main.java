package com.javalec.base;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.javalec.function.Calc;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Main extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JTextField tfNum1;
	private JTextField tfNum2;
	private JTextField tfRNum1;
	private JTextField tfRNum2;
	private JButton btnAdd;
	private JButton btnSub;
	private JButton btnMul;
	private JButton btnDiv;
	private JTextField tfResult;
	private JLabel idiNewLabel_2;
	private JLabel ibiSign;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblNewLabel());
		contentPane.add(getLblNewLabel_1());
		contentPane.add(getTfNum1());
		contentPane.add(getTfNum2());
		contentPane.add(getTfRNum1());
		contentPane.add(getTfRNum2());
		contentPane.add(getBtnAdd());
		contentPane.add(getBtnSub());
		contentPane.add(getBtnMul());
		contentPane.add(getBtnDiv());
		contentPane.add(getTfResult());
		contentPane.add(getIdiNewLabel_2());
		contentPane.add(getIbiSign());
	}

	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("숫자1 :");
			lblNewLabel.setBounds(36, 56, 61, 16);
		}
		return lblNewLabel;
	}
	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("숫자2 :");
			lblNewLabel_1.setBounds(36, 113, 61, 16);
		}
		return lblNewLabel_1;
	}
	private JTextField getTfNum1() {
		if (tfNum1 == null) {
			tfNum1 = new JTextField();
			tfNum1.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent e) {
					// TectField에 숫자외의 문자가 입력되면 지우기 
					if(e.getKeyChar() >= '0' && e.getKeyChar() <= '9') {
						
					}else {
						JOptionPane.showMessageDialog(null, "숫자만 입력하세요", "경고",JOptionPane.ERROR_MESSAGE);
						tfNum1.setText("");
					}
				}
			});
			tfNum1.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
			tfNum1.setHorizontalAlignment(SwingConstants.TRAILING);
			tfNum1.setBounds(109, 56, 130, 26);
			tfNum1.setColumns(10);
		}
		return tfNum1;
	}
	private JTextField getTfNum2() {
		if (tfNum2 == null) {
			tfNum2 = new JTextField();
			tfNum2.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
			tfNum2.setHorizontalAlignment(SwingConstants.TRAILING);
			tfNum2.setBounds(109, 113, 130, 26);
			tfNum2.setColumns(10);
		}
		return tfNum2;
	}
	private JTextField getTfRNum1() {
		if (tfRNum1 == null) {
			tfRNum1 = new JTextField();
			tfRNum1.setForeground(new Color(0, 0, 255));
			tfRNum1.setFont(new Font("Lucida Grande", Font.BOLD, 13));
			tfRNum1.setHorizontalAlignment(SwingConstants.TRAILING);
			tfRNum1.setBounds(36, 204, 93, 26);
			tfRNum1.setColumns(10);
		}
		return tfRNum1;
	}
	private JTextField getTfRNum2() {
		if (tfRNum2 == null) {
			tfRNum2 = new JTextField();
			tfRNum2.setForeground(new Color(0, 0, 255));
			tfRNum2.setFont(new Font("Lucida Grande", Font.BOLD, 13));
			tfRNum2.setHorizontalAlignment(SwingConstants.TRAILING);
			tfRNum2.setBounds(183, 204, 85, 26);
			tfRNum2.setColumns(10);
		}
		return tfRNum2;
	}
	private JButton getBtnAdd() {
		if (btnAdd == null) {
			btnAdd = new JButton("+");
			btnAdd.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					addition();
				}
			});
			btnAdd.setBounds(269, 53, 61, 29);
		}
		return btnAdd;
	}
	private JButton getBtnSub() {
		if (btnSub == null) {
			btnSub = new JButton("-");
			btnSub.setBounds(354, 53, 61, 29);
		}
		return btnSub;
	}
	private JButton getBtnMul() {
		if (btnMul == null) {
			btnMul = new JButton("x");
			btnMul.setBounds(269, 110, 61, 29);
		}
		return btnMul;
	}
	private JButton getBtnDiv() {
		if (btnDiv == null) {
			btnDiv = new JButton("/");
			btnDiv.setBounds(354, 110, 61, 29);
		}
		return btnDiv;
	}
	private JTextField getTfResult() {
		if (tfResult == null) {
			tfResult = new JTextField();
			tfResult.setForeground(new Color(255, 0, 0));
			tfResult.setFont(new Font("Lucida Grande", Font.BOLD, 13));
			tfResult.setHorizontalAlignment(SwingConstants.TRAILING);
			tfResult.setColumns(10);
			tfResult.setBounds(315, 204, 100, 26);
		}
		return tfResult;
	}
	private JLabel getIdiNewLabel_2() {
		if (idiNewLabel_2 == null) {
			idiNewLabel_2 = new JLabel("+");
			idiNewLabel_2.setBounds(146, 209, 26, 21);
		}
		return idiNewLabel_2;
	}
	private JLabel getIbiSign() {
		if (ibiSign == null) {
			ibiSign = new JLabel("=");
			ibiSign.setBounds(280, 209, 26, 16);
		}
		return ibiSign;
	}
	
	//-----------
	private void addition() {
		idiNewLabel_2.setText("+");
		tfRNum1.setText(tfNum1.getText());
		tfRNum2.setText(tfNum2.getText());
	
		Calc calc = new Calc(tfNum1.getText(), tfNum2.getText());
		tfResult.setText(Calc.);
	
	}
	
	
	
	
	
	
	
	
	
}// End
