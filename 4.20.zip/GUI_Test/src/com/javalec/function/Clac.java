package com.javalec.function;

public class Clac {

	int num1;
	int num2;
	
	
	public Clac() {
		// TODO Auto-generated constructor stub
	}


	public Clac(int num1, int num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
	}
	
	
	public int add() {
		return num1 + num2;
	}
	
	public int sub() {
		return num1 - num2;
	}
	
	public int mul() {
		return num1 * num2;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
