package com.javalec.base;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.javalec.function.Clac;


import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.UIManager;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Main extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JTextField textField;
	private JTextField textField_1;
	private JButton bfNum1;
	private JButton bfNum2;
	private JButton bfNum3;
	private JButton bfNum4;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField tfResult;
	private JLabel lblNewLabel_2;

	
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setTitle("두개의 숫자 가감승제");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(230, 230, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblNewLabel());
		contentPane.add(getLblNewLabel_1());
		contentPane.add(getTextField());
		contentPane.add(getTextField_1());
		contentPane.add(getBfNum1());
		contentPane.add(getBfNum2());
		contentPane.add(getBfNum3());
		contentPane.add(getBfNum4());
		contentPane.add(getTextField_2());
		contentPane.add(getTextField_3());
		contentPane.add(getTfResult());
		contentPane.add(getLblNewLabel_2());
	}

	
	
	
	
	
	
	
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("숫자1:");
			lblNewLabel.setBounds(30, 39, 43, 16);
		}
		return lblNewLabel;
	}
	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("숫자2:");
			lblNewLabel_1.setBounds(30, 94, 43, 16);
		}
		return lblNewLabel_1;
	}
	private JTextField getTextField() {
		if (textField == null) {
			textField = new JTextField();
			textField.setHorizontalAlignment(SwingConstants.TRAILING);
			textField.setBounds(85, 34, 109, 26);
			textField.setColumns(10);
		}
		return textField;
	}
	private JTextField getTextField_1() {
		if (textField_1 == null) {
			textField_1 = new JTextField();
			textField_1.setHorizontalAlignment(SwingConstants.TRAILING);
			textField_1.setBounds(85, 89, 109, 26);
			textField_1.setColumns(10);
		}
		return textField_1;
	}
	private JButton getBfNum1() {
		if (bfNum1 == null) {
			bfNum1 = new JButton("+");
			bfNum1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					clac("add");
				}
			});
			bfNum1.setBounds(241, 34, 52, 29);
		}
		return bfNum1;
	}
	private JButton getBfNum2() {
		if (bfNum2 == null) {
			bfNum2 = new JButton("-");
			bfNum2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					clac("sub");
				}
			});
			bfNum2.setBounds(305, 34, 52, 29);
		}
		return bfNum2;
	}
	private JButton getBfNum3() {
		if (bfNum3 == null) {
			bfNum3 = new JButton("x");
			bfNum3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					clac("mul");
				}
			});
			bfNum3.setBounds(241, 89, 52, 29);
		}
		return bfNum3;
	}
	private JButton getBfNum4() {
		if (bfNum4 == null) {
			bfNum4 = new JButton("/");
			bfNum4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					division();
				}
			});
			bfNum4.setBounds(305, 89, 52, 29);
		}
		return bfNum4;
	}
	private JTextField getTextField_2() {
		if (textField_2 == null) {
			textField_2 = new JTextField();
			textField_2.setForeground(new Color(0, 0, 255));
			textField_2.setEditable(false);
			textField_2.setFont(new Font("Lucida Grande", Font.BOLD, 13));
			textField_2.setBounds(42, 213, 95, 26);
			textField_2.setColumns(10);
		}
		return textField_2;
	}
	private JTextField getTextField_3() {
		if (textField_3 == null) {
			textField_3 = new JTextField();
			textField_3.setForeground(new Color(0, 0, 255));
			textField_3.setEditable(false);
			textField_3.setFont(new Font("Lucida Grande", Font.BOLD, 13));
			textField_3.setBounds(185, 213, 95, 26);
			textField_3.setColumns(10);
		}
		return textField_3;
	}
	private JTextField getTfResult() {
		if (tfResult == null) {
			tfResult = new JTextField();
			tfResult.setForeground(new Color(255, 0, 0));
			tfResult.setEditable(false);
			tfResult.setFont(new Font("Futura", Font.BOLD, 13));
			tfResult.setBounds(320, 213, 95, 26);
			tfResult.setColumns(10);
		}
		return tfResult;
	}
	
	//------- function -------------
	
	
	public void clac(String part) {
		int number1 = Integer.parseInt(bfNum1.getText());
		int number2 = Integer.parseInt(bfNum2.getText());
		String result = "";
		
		Clac clac = new Clac(number1, number2);
		
		for(part.equals("add")) {
			result = Integer.toString(clac.add());
		}if(part.equals("sub")) {
			result = Integer.toString(clac.sub());
		}if(part.equals("mul")) {
			result = Integer.toString(clac.mul());	
		}
				
		
		
		tfResult.setText(result);
	}
	
	
	public void calc(String part) {
		int number1 = Integer.parseInt(bfNum1.getText());
		int number2 = Integer.parseInt(bfNum2.getText());
		
		
		Clac clac = new Clac(number1, number2);
		String result = Integer.toString(clac.sub());
		
		
		tfResult.setText(result);
		
	}
	
	
	public void calc(String part) {
		int number1 = Integer.parseInt(bfNum1.getText());
		int number2 = Integer.parseInt(bfNum2.getText());
		
		
		Clac clac = new Clac(number1, number2);
		String result = Integer.toString(clac.mul());
		
		
		tfResult.setText(result);
		
	}
	
	public void division() {
		
	}
	
	
	
	
	
	
	
	private JLabel getLblNewLabel_2() {
		if (lblNewLabel_2 == null) {
			lblNewLabel_2 = new JLabel("=");
			lblNewLabel_2.setBounds(293, 218, 26, 16);
		}
		return lblNewLabel_2;
	}
}// End
