package com.javalce.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int Mony1 = 8000, Mony2 = 7999, Mony3 = 5000, Mony4 = 4999, Mony5 = 3000, Mony6 = 2999, Mony7 = 0;
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("금액을 입력하세요! :");
		
		
		
		if(Mony1 >= 8000) {
			System.out.println("너무 비쌉니다.");
		}else if(Mony3 <= Mony2) {
			System.out.println("조금 비쌉니다.");
		}else if(Mony5 <= Mony4) {
			System.out.println("적당한 금액 입니다.");
		}else if(Mony7 <= Mony6) {
			System.out.println("싼 편입니다.");
		}
		
		// 문제점 (가격을 하나하나 적을 필요없이 price로 가격을 설정하고 작업하면된다. 또한 아웃풋을 적어야함.)
		
		
		
		
	}

}
