package com.javalec.function;

public abstract class StoreShop1 extends StoreHQ {

	@Override
	public void orderKim() {
		// TODO Auto-generated method stub

	}

	@Override
	public void orderBu() {
		// TODO Auto-generated method stub

	}

	@Override
	public void orderBi() {
		// TODO Auto-generated method stub

	}

}
