package com.javalec.function;

public abstract class StoreHQ {

	public  StoreHQ() {
		// TODO Auto-generated constructor stub
	}
	
	public abstract void orderKim();
	public abstract void orderBu();
	public abstract void orderBi();
	
	
	
}
