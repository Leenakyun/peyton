package com.javalec.base;

import java.util.HashMap;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Map, Dictionary   :  Key와 Value 구성 
		
		HashMap<String, String> hashMap = new HashMap<>();          // arraylist 보다 메모리값이 2배가 든다. 
		
		hashMap.put("Apple", "사과");
		hashMap.put("Banana", "바나나");
		
		
		System.out.println(hashMap);
		System.out.println(hashMap.get("Apple"));
		
		hashMap.remove("Apple");
		System.out.println(hashMap);
		
		
		
		
		
	}

}
