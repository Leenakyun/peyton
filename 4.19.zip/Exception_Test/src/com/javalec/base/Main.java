package com.javalec.base;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		/*
		 * 입력할 숫자의 갯수? 5
		 * 5개의 숫자를 입력하세요! :
		 * 1의 숫자 : 1
		 * 2의 숫자 : 2
		 * 3의 숫자 : 3
		 * 4의 숫자 : 4
		 * 5의 숫자 : 5
		 * 몇번째 숫자를 삭제 하시겠습니까? : 3
		 * -----------결과 -------------
		 * 1
		 * 2
		 * 4       intege(숫자 입력시 필요.)
		 * 5
		 */
		
		Scanner scanner = new Scanner(System.in);
		int name =0;     // 입력 숫자 갯수 
		int num1 =0;    /// 입력 받은 숫자 
		int num2 =0;     // 삭제숫자 
		
		
		System.out.print("입력할 숫자의 갯수? :");
		name = scanner.nextInt();     
		
		System.out.println(name + "개의 숫자를 입력하세요!");
		
		ArrayList<Integer> arrayList = new ArrayList<>();
		
		for(int i =0; i<name; i++) {
			System.out.println((i+1) + "의 숫자 :");
			num1 = scanner.nextInt();
			arrayList.add(num1);
		}
		
		System.out.println("몇번째의 숫자를 삭제 하시겠습니까? :");
		num2 = scanner.nextInt();
		
		arrayList.remove(num2-2);
		
		System.out.println("-------- 결과 -------");
		for(int i=0; i< arrayList.size(); i++) {
			System.out.println(i);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
