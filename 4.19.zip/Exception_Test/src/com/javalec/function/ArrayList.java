package com.javalec.function;

public class ArrayList {

}
