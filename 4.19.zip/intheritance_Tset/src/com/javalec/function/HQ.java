package com.javalec.function;

public class HQ {

	
	
	
	public HQ() {
		// TODO Auto-generated constructor stub
	}
	
	public void hq() {
		System.out.println("HQ--------------------");
	}
	
	public void makeKim() {
		System.out.println("김치찌개 : 5,000원");
	}
	public void makeBuu() {
		System.out.println("부대찌개 : 6,000");
	}
	public void makeBi() {
		System.out.println("비빔밥 : 6,000");
	}
	public void makeSun() {
		System.out.println("순대국 : 5,000");
	}
	public void makeGong() {
		System.out.println("공기밥 : 1,000");
	}
	
	
	
}
