package com.javalec.function;

public class Shop_01 extends HQ{

	
	public Shop_01() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
	
	public void shop1() {
		System.out.println("Shop1--------------------");
	}
	@Override
	public void makeKim() {
		System.out.println("김치찌개 : 4,500원");
	}
	@Override
	public void makeBuu() {
		System.out.println("부대찌개 : 5,000");
	}
	
	@Override
	public void makeSun() {
		System.out.println("순대국 : 판매하지 않습니다.");
	}
	
	
	
	
	
	
	
}
