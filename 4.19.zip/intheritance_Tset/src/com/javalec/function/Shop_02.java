package com.javalec.function;

public class Shop_02 extends HQ{

	
	public Shop_02() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	public void shop2() {
		System.out.println("Shop2--------------------");
	}
	

	
	@Override
	public void makeBuu() {
		System.out.println("부대찌개 : 5,000");
	}
	@Override
	public void makeBi() {
		System.out.println("비빔밥 : 5,000");
	}
	@Override
	public void makeSun() {
		System.out.println("순대국 : 4,000");
	}
	@Override
	public void makeGong() {
		System.out.println("공기밥 : 무료 입니다.");
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
