package com.javalec.function;

public class Shop_03 extends HQ{

	
	public Shop_03() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	public void shop3() {
		System.out.println("Shop3--------------------");
	}
	@Override
	public void makeKim() {
		System.out.println("김치찌개 : 7,000원");
	}
	@Override
	public void makeBuu() {
		System.out.println("부대찌개 : 7,000");
	}
	@Override
	public void makeBi() {
		System.out.println("비빔밥 : 7,000");
	}
	@Override
	public void makeSun() {
		System.out.println("순대국 : 6,000");
	}

	
	
	
	
	
	
	
	
	
	
}
