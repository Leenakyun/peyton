package com.javalec.base;

import com.javalec.function.HQ;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println("HQ-------------------");
	
		HQ hq = new HQ();
		hq.makeKim();
		hq.makeBuu();
		hq.makeBi();
		hq.makeSun();
		hq.makeGong();
		
		
		System.out.println("Shop1-------------------");
		Shop[] shop = {new Shop1(), new Shop2(), new Shop3()}; 
		
		for(int i =0; i<shop.length; i++) {
			shop[i].makeKim();
			shop[i].makeBuu();
			shop[i].makeBi();
			shop[i].makeSun();
			shop[i].makeGong();
		}
		
		
		
		System.out.println("Shop2-------------------");
		
		
		
		
		
		System.out.println("Shop3-------------------");
		
		
		
		
		
		
		
		
		
		
		
		
	}

	
	
}
