
public class String {

	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub

	}

}
