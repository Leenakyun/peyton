package com.javalec.base;

import java.util.Scanner;

public class Calendar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		
		Calendar calendar = Calendar.getinstance();
		String[] dateName = ("일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일")
		
		
		int year = calendar.get(Calendar.YEAR);       // year은 int
		int month = calendar.get(Calendar.MONTH) +1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int date = calendar.get(Calendar.DAY_OF_WEEK);
		
		int hour = calendar.get(Calendar.HOUR);
		int minute = calendar.get(Calendar.MINUTE);
		int second = calendar.get(Calendar.SECOND);
		
		
		
		
		
		System.out.println(year + "." + month + "." + day + "." + "(" + dateName[date-1] + ")");
		System.out.println(hour + ":" + minute + ":" + second);
		
		
	}
	
}
