package com.javalec.base;

import java.util.Scanner;

public class Main_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		// String
		
		String str1 = "a";
		long startTime1 = System.currentTimeMillis();
		for(int i=1; i<=500000; i++) {
			str1 = str1 + "a";
		}
		
		long endTime1 = System.currentTimeMillis();
		
		System.out.println("term1" + (endTime1 - startTime1));
		
		/*
		 * -------
		 * StringBuilder
		 */
		StringBuilder stringBuilder =new StringBuilder();
		long startTime2 = System.currentTimeMillis();
		for(int i=1; i<=500000; i++) {
			stringBuilder.append("a");
		}
		long endTime2= System.currentTimeMillis();
		
		System.out.println("term1" + (endTime1 - startTime2));
	}

}
