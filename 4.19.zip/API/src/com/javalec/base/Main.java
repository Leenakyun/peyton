package com.javalec.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/*
		 * scanner, string 등 대문자로 시작하는 문법은 클레스다. 
		 * 
		 * 클라스에 .을 찍었을때 나오는것이 메소드이다. 
		 * 
		 */
		Scanner scanner = new Scanner(System.in);
		
		String str0 = new String("가나다라마바사");
		String str1 = "abcdefg";
		String str2 = "HIJKLMN";
		String str3 = "   abc   ";
		
		System.out.println(str1.concat(str2));       // .concat은 문자를 연결해주는 메소드 
	
		System.out.println(str1.substring(3));       // 문자열 자르기 
		
		System.out.println(str0.substring(3, 5));    // 범위를 제한
		
		System.out.println(str0.length());           // 문자의 길이 (아이디, 패스워드 글자수 제한할때 많이 사용)
		
		System.out.println(str1.toUpperCase());      // 대문자로 변환 
		
		System.out.println(str1.toUpperCase().concat(str2));      // 대문자로 변환후 str2를 연결시키겠다는 뜻 . 
		
		System.out.println(str2.toLowerCase());                        //  대문자와 소문자를 통일 시켜야 컴퓨터가 서치 가능 
		
		System.out.println(str1.charAt(0));                 // ''을 사용해야함.
		
		System.out.println(str1.indexOf('a'));
		
		System.out.println(str1.equals(str2));
		
		System.out.println(str3);
		
		System.out.println(str3.trim());               // 문자열 뒤의 스페이스바의 빈 공간을 지워주는 메소드.  입력할때 문자열의 뒤쪽 스페이스바 공간을 꼭 제거해줘야함. 
		
		System.out.println(str1.replace('a', 'z'));
		
		System.out.println(str1.replaceAll("abc", "zzzzzz"));  
		
		
		
		String number = "010-1212-3434";
	/*	
		// 010-1212-3434 -> 010-****-****
		System.out.println(number.replaceAll("1212-3434", "****-****"));
		*/
		
		//강사님의 답. 
		
		System.out.println(number.replaceAll(number.substring(4), "****-****"));
		
		System.out.println(number.substring(0, 4).concat("****-****"));
		
		
		
		
		
		
	}

}
