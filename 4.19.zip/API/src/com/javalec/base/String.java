package com.javalec.base;

import java.util.Scanner;

public class String {

	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub
Scanner scanner = new Scanner(System.in);
		
		String str1 = new String("abc");
		
		StringBuilder stringBuilder = new StringBuilder("abcdefg");
		
		stringBuilder.append("hijklmn");
		System.out.println(stringBuilder);
		
		stringBuilder.insert(3, "zzz");
		System.out.println(stringBuilder);
		
		stringBuilder.delete(3, 6);
		System.out.println(stringBuilder);
		
		
		
		
	}

}
