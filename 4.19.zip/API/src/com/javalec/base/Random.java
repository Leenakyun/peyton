package com.javalec.base;

import java.util.Scanner;

public class Random {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		Random random = new Random();
		System.out.println(random.nextint(10));
		
		for(int j=1; j<=6; j++) {
			int i = random.nextint(45);
			System.out.println(i+1);
		}
		
		
		
		
	}

}
