package com.javalec.base;

public class Hello {

	public static void main(String[] args) {
		/*
		 *  줄줄히 쓸수있는 *
		 */
//		화면에 Hello 출력하기  (맥 : 커맨드 / 쓰면 문자열 바로 사용 가능)   
		System.out.print("Hello!\n");
		System.out.println("\tWorld\t");
		// 커먼드 + Art + 아래 화살표는 아래 열에 코드 복사하기 
		// 커멘드 + Art + Del 열 지우기 
		// 클라스의 처음 시작은 대문자로 시작  정의할떄는 
		// 메소드로 만들고 .으로 사용한다.  
		// print 줄 안띄우고 이어 쓰기 
		// println 줄 띄우고 쓰기 
		// \n 띄어 쓰기                  \ :Backspace 키 왼쪽 의 달러표시  
		// \t \t 는 Tap해서 쓰기 
		
	}

}
