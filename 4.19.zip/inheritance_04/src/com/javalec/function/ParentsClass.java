package com.javalec.function;

public class ParentsClass {

	public ParentsClass() {
		// TODO Auto-generated constructor stub
		System.out.println("Parents Class");
	}
	
	public void method() {
		System.out.println("Parents Method");
	}
	
	
	
	
}
