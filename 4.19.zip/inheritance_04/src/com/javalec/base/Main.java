package com.javalec.base;

import com.javalec.function.ChildClass;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ChildClass childClass = new ChildClass();
		
		
		
	}

}


