package com.javalec.base;

import java.security.PublicKey;
import java.sql.Array;
import java.util.ArrayList;

public class Main {

	private static int i;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Customer> customers = new ArrayList<>();
		
		
		Customer customer = new Customer(1, "james", "010 -1111-2222");
		
		
		customer.add(customer);
		System.out.println(customers.get(0).getName());
		
		
		//-------
		
		Customer customer2 = new Customer();
		
		customer2.setNumber(2);
		customer2.setName("Cathy");
		customer2.setPhone("010-7777-8888");
		
		
		customer.add(customer2);
		System.out.println(customers.get(1).getName());
	
		
		//------
		Customer customer3 = new Customer(3, "Maria", "010-3333-4444");
		customers.add(customer3);
		
		for(int i =0; i<customers.size(); i++);{
			System.out.println("|");
			System.out.println(customers.get(i).getNumber());
			System.out.println("|");
			System.out.println(customers.get(i).getName());
			System.out.println("|");
			System.out.println(customers.get(i).getPhone());
			System.out.println("|");
		}
		
		
		
		
		
	}

}
