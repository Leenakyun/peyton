package com.javalec.base;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		// ArrayList
		ArrayList<String> arrayList = new ArrayList<>();              // 해당 괄호는 제너릭(<>)이란것.     <>안의 String을 적으면 문자열만 적을수있다. 
		
		arrayList.add("str1");
		arrayList.add("str2");
		arrayList.add("str3");
		arrayList.add("str4");
		
		System.out.println(arrayList);
		System.out.println(arrayList.size());
		
		for(int i =0; i<arrayList.size(); i++) {
			System.out.println(arrayList.get(i));
		}
		
		arrayList.set(1, "str22");
		System.out.println(arrayList);
		
		arrayList.remove(1);
		System.out.println(arrayList);

		arrayList.add(0,"AAA");
		System.out.println(arrayList);

		
		arrayList.clear();
		System.out.println(arrayList);
		
		
	}

}
