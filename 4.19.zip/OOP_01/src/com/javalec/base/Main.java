package com.javalec.base;

import java.util.Scanner;

import com.javalec.function.Calc;
import com.javalec.function.SumEvenOddConst;
import com.javalec.function.SumEvenOddField;
import com.javalec.function.SumEvenOddMethod;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//1~10까지의 합계를 구하고 그합이 짝수 인지 홀수인지 판별
	/*	int sum =0;
		
		for(int i=0; i<=10; i++) {                       이런 수식은 안됨. 
			sum += i;
		}
		System.out.println()"1~10 까지의 합은?" + sum);
		
		if(sum % 2 == 0) {
			System.out.println("짝수");
		}else {
			System.out.println("홀수");
		}
		*/
	/*	
		SumEvenOdd sumEvenOdd = new SumEvenOdd();
		
		int result = sumEvenOdd.sumCalc(1, 10);
		
		System.out.println("1부터 10까지의 합계는 " + result);
		
		result = sumEvenOdd.sumCalc(100, 1000);
		
		System.out.println("100부터 1000까지의 합계는 " + result);
	*/	
		
		
	/*짝수 홀수 합계구하기 
	 * 	
	 */
	
	/*	int total = 0;      //합계
		String totalEvenOdd = "";  //total 의 짝홀수 판별 
		
		SumEvenOdd sumEvenOdd = new SumEvenOdd();
		
	/*	String evenOdd = sumEvenOdd.evenOdd(result);
		System.out.println("1부터 10까지의 합계는 " + evenOdd);    */
		
/*		total = sumEvenOdd.sumCalc(1, 10);
		System.out.println("1부터 10까지의 합계는 " + total);
		
		totalEvenOdd = sumEvenOdd.evenOdd(total);
		System.out.println("1부터 10까지의 합계 " + totalEvenOdd);     */

		
		
		
		
		// 사용자로 부터 숫자 2개를 입력받아 범위의 합계를 구하고 짝수 홀수 판단. 
		
	//	SumEvenOdd sumEvenOddMethod = new SumEvenOdd();
		Scanner scanner = new Scanner(System.in);
		int startNum = 0;   // 범위의 첫번째 숫자 
		int endNum = 0;   // 범위의 두번째 숫자 
		int total = 0;      //합계
		String totalEvenOdd = "";  //total 의 짝홀수 판별 
		
	
		System.out.print("범위의 첫번쨰 숫자를 입력하세요 :");
		startNum = scanner.nextInt();
		System.out.print("범위의 두번쨰 숫자를 입력하세요 :");
		endNum = scanner.nextInt();
		
		
		
	/*	  Meathod (메소드 활용)
		total = sumEvenOdd.sumCalc(startNum, endNum);
		System.out.println(startNum +"부터" + endNum + "까지의 합계는 " + total);
		
		totalEvenOdd = sumEvenOdd.evenOdd(total);
		System.out.println(startNum +"부터" + endNum + "까지의 합계 " + totalEvenOdd);
		*/
	
		
		
		//------------------------------------------------------------------------
/*		
		System.out.println("****** Field 활용 ********");
		
		SumEvenOddField sumEvenOddField = new SumEvenOddField();
		sumEvenOddField.startNum = startNum;
		sumEvenOddField.endNum = endNum;
		
		total = sumEvenOddField.sumCalc();
		System.out.println(startNum +"부터" + endNum + "까지의 합계는 " + total);
		
		totalEvenOdd = sumEvenOddField.evenOdd();
		System.out.println(startNum +"부터" + endNum + "까지의 합계 " + totalEvenOdd);
		*/
		//---------------------------------------------------------------------------
	/*	
		System.out.println("****** Constructor 활용 ********");
		
		SumEvenOddConst sumEvenOddConst = new SumEvenOddConst(startNum, endNum);
		
		total = sumEvenOddConst.sumCalc();
		System.out.println(startNum +"부터" + endNum + "까지의 합계는 " + total);
		
		totalEvenOdd = sumEvenOddConst.evenOdd();
		System.out.println(startNum +"부터" + endNum + "까지의 합계 " + totalEvenOdd);
		
		*/
/*		
		SumEvenOddMethod sumEvenOdd = new SumEvenOddMethod();
		
		
		
		
		int number = sumEvenOdd.sumCalc(startNum, endNum);
		
		System.out.println(number);
		
		
		/*
		 * 한줄 입력으로 덧셈,빼기, 나눗셈, 곱셈이 나오도록 해보자. 
		 */
//    	*/
/*	
	구구단
	
	몇단부터 시작할가요? : 2
	몇단에서 끝내시겠습니까? :5
	
	곱해지는 수는 몇으로 시작할까요? 3
	곱해지는 수는 몇으로 끝낼까요? 7
	*/
	
	
	
	
	
	
	
	
