package com.javalec.function;

public class SumEvenOddMethod {

	// Field, Property
	
	// Constructor    (생성기능)   기능들은 조그만 하게 만들어야함. 
	
	public SumEvenOddMethod() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	// Method (기능)
	// 합계를 구한다. 
/*	public int sumCalc(int startNum, int endNum) {
		int sum = 0;
		for(int i= startNum; i<= endNum; i++) {
		sum += i;
	}
		return sum;
	}
	
	// 짝수 홀수 판단. 
/*	
	public String evenOdd(int sum) {
		String result = "";                                               // string 과 int에 배열또한 사용가능 
		if(sum % 2 ==0) {
			result = "짝수 입니다.";
		}else {
			result = "홀수 입니다.";
		} return result;
		}*/
	
	/*
	 * 2개의 숫자를 입력 받아
	 * 덧셈, 뺄셈, 곱셈, 나눗셈, 결과를 실행하는 클래스를 생성하여
	 * 결과를 도출 하시오.
	 * 1) Field
	 * 2) Constructor
	 * 3) Method
	 */
	// 덧셈 
	public int startNum = 0;
	public int endNum = 0;
	public int sum =0;
	
	public int sumCalc(int startNum, int endNum) {
		int sum = startNum + endNum;
		
	}public int abinCalc(int startNum, int endNum) {
			int sum = startNum - endNum;
				
	}public int acCalc(int startNum, int endNum) {
			int sum = startNum * endNum;
						
				
				/*for(int i = startNum; i<= endNum; i++) {
		sum -= i;
	}*/
	
		return sum;
	}
	public int adCalc(int startNum, int endNum) {
		int sum = startNum / endNum;
	
	
}
}