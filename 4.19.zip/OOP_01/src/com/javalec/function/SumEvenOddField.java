package com.javalec.function;

public class SumEvenOddField {

	// Field
	public int startNum =0;
	public int endNum =0;
	public int sum = 0;
	
	
	
	
	
	
	
	// 합계를 구한다. 
		public int sumCalc() {
			sum = 0;
			for(int i= startNum; i<= endNum; i++) {
			sum += i;
		}
			return sum;
		}
		
		// 짝수 홀수 판단. 
		
		public String evenOdd() {
			String result = "";                                              
			if(sum % 2 ==0) {
				result = "짝수 입니다.";
			}else {
				result = "홀수 입니다.";
			} return result;
			}
	
	
	// Constructor
	public SumEvenOddField() {
		// TODO Auto-generated constructor stub
	}
	//Method
	
	/* 2개의 숫자를 입력 받아
	 * 덧셈, 뺄셈, 곱셈, 나눗셈, 결과를 실행하는 클래스를 생성하여
	 * 결과를 도출 하시오.
	 * 1) Field
	 * 2) Constructor
	 * 3) Method
	 */
	
	
	
	
	
	
	
}
