package com.javales.base;

public class Main {

	public static void main(String[] args) {
		// Data출력 
		System.out.println("1234");  // "" 안에있는 것은 문자.
		System.out.println(1234);   // 문자인지 숫자인지 처음에는 모르지만 무조건 문자로 출력됨. 
		System.out.println(10 + 20);   // 결과 값이 출력됨.  
		System.out.println("10 + 20");   // ""안에는 문자로 출력이됨. 
		System.out.println("10 + 20 = " + (10 + 20));  // 계산할 시간을 주려면 괄호가 필요함. 
		System.out.println("10 - 20 = " + (10 - 20));  // 괄호안의 숫자 먼저 작용이됨.  
		System.out.println("10 * 20 = " + (10 * 20));    
		System.out.println("10 / 20 = " + (10.0 / 20));  // 프로그램마다 다르지만 java는 정수는 정수만 보여준다. 실수값이 필요하다면 하나의 숫자를 실수로 만들어야한다. 
		System.out.println("10 / 20 = " + ((double)10 / 20));  // 실수를 표기하기위한 코드는 double 이다. 
		System.out.println("10 % 20 = " + (10 % 20));  // 몫과 나머지값을 표기하기위해 %를 쓴다.  

		// 변수 
		int num1 = 10;  // int는 한 이름당 하나씩 적용된다. int의 노란줄은 변수를 만들고서 한번도 안썼다는 뜻. 
		num1 = 100;
		int num2 = 200; // 세미 클론이있다면 한줄에 다 써도 되지만 기독성이 떨어짐. 비추천 
		
		// 변수 num1과 num2의 덧셈을 출력하기
		System.out.println(num1 + "+" + num2 + "=" + (num1 + num2));
		
	}

}
