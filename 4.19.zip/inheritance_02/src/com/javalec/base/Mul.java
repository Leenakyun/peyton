package com.javalec.base;

public class Mul extends Add{

	
	public Mul() {
		// TODO Auto-generated constructor stub
	}
	
	public void multilication() {
		System.out.println(num1 / num2);
	}
	
}
