package com.javalec.base;

public class AddM {

	public AddM() {
		// TODO Auto-generated constructor stub
	}
	
	public void addition(int num1, int num2) {
		System.out.println(num1 + num2);
	}
	
	
	
}
