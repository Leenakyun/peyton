package com.javalec.base;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	Mul mul = new Mul();
	mul.num1 = 10;
	mul.num2 = 20;
	
	mul.addition();
	mul.subtraction();
	mul.multilication();
	
	
	MulM mulM = new MulM();
	mulM.addition(20, 30);
	mulM.subtraction(20, 30);
	mulM.multilication(20, 30);
	
	
	
	
	MulC mulC = new MulC(30, 40);
	mulC.addition():
	mulC.subtraction();
	mulC.multiplication();
	
	
	
	
}
