package com.javalec.base;

public class Add {

	
	public int num1;
	public int num2;
	
	public Add() {
		// TODO Auto-generated constructor stub
	}
	
	public void addition() {
		System.out.println(num1 + num2);
	}
	
	
	
	
	
	
	
}
