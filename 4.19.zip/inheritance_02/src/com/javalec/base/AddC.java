package com.javalec.base;

public class AddC {

	
	
	int num1;
	int num2;
	
	
	
	public AddC() {
		// TODO Auto-generated constructor stub
	}


	public AddC(int num1, int num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
	}
	
	
	
	
	public void addition() {
		System.out.println(num1 + num2);
	}
	
	
	
	
	
	
	
}
