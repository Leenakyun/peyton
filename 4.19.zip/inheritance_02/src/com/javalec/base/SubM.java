package com.javalec.base;

public class SubM extends AddM{

	public SubM() {
		// TODO Auto-generated constructor stub
	}
	
	
	public void subtraction(int num1, int num2) {
		System.out.println(num1 - num2);
	}
	
	
}
