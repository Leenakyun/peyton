package com.javalec.base;

public class Sub extends Add{

	public Sub() {
		// TODO Auto-generated constructor stub
	}
	
	
	public void subtraction() {
		System.out.println(num1 - num2);
	}
	
	
}
