package com.javalec.base;

public class MulC extends SubC{

	public MulC() {
		// TODO Auto-generated constructor stub
	}

	public MulC(int num1, int num2) {
		super(num1, num2);
		// TODO Auto-generated constructor stub
	}
	
	
	public void multiplication() {
		System.out.println(num1 * num2);
	}
	
	
	
	
	
}
