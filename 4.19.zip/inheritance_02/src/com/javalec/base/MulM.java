package com.javalec.base;

public class MulM extends AddM{

	
	public MulM() {
		// TODO Auto-generated constructor stub
	}
	
	public void multiplication(int num1, int num2) {
		System.out.println(num1 * num2);
	}
	
}
