package com.javalec.base;

public class Parents {

	// Field 
	
	String pStr = "부모Class";
	public int startNum;
	public int endNum;
	public int result;
	
	
	
	// Constructor
	
	public Parents() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Parents(int startNum, int endNum, int result) {
		super();
		this.startNum = startNum;
		this.endNum = endNum;
		this.result = result;
	
	}



	// Method
	
	public void getFather() {
		System.out.println("Father");
	}
	
	public void getMother() {
		System.out.println("Mother");
	}
	
	public int addCale() {
		result = startNum + endNum;
		return result;
	}
	
	
	
	
	
}
