package com.javalec.base;

public class Child extends Parents {

	// Field
	String cStr = "자식 Class";
	
	
	
	
	// Constructor
	public Child() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	// Method
	
	public void getChild() {
		System.out.println("Child");
	}
	
	
	
	
	
	
}
