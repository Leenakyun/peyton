package com.javalec.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	// 앱을 만들떄 유저 인터페이스 부터 설계한다. 
	
	
	Parents parents = new Parents();	
	Scanner scanner = new Scanner(System.in);
	
	int firstNum = 0;
	int secondNum = 0;
	
	
/*		
	Child child = new Child();
	child.getFather();
	child.getMother();
	child.getChild();
	
	System.out.println(child.pStr);
	System.out.println(child.cStr);     // 펑션에서 불러오기가 안될경우 펑션의 클레스에서 public을 했는지 확인 해야한다. 
	*/
	
	System.out.print("첫번쨰 숫자를 입력하세요 :");
	firstNum = scanner.nextInt();
	
	System.out.print("두번쨰 숫자를 입력하세요 :");
	secondNum = scanner.nextInt();
	
	
	/*
	 * 사용자로 부터 2개의 숫자를 입력받아 덧셈, 뺄셈, 곱셈, 나눗셈의 결과를 보여주려고 한다. 
	 * (단)
	 * 1) Main Method에서는 Class 하나만 사용할 것이다.
	 * 2) 덧셈, 뺄셈, 곱셈, 나눗셈의 기능은 각각의 클래스로 작성한다.
	 * 3) 덧셈 클래스는 덧셈만 제공한다.
	 * 4) 뺄셈 클래스는 덧셈과 뺄셈을 제공한다.
	 * 5) 곱셈 클래스는 덧셈, 뺄셈, 곱셈을 제공한다.
	 * 6) 나눗셈 클래스는 덧셈, 뺄셈, 곱셈을 제공한다.
	 */
	
	Parents.result();
	
	
	
	
	
	
	
	}

}
