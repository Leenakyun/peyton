package com.javalce.base;

import com.javalec.function.ChildMenu;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}


	ChildMenu childMenu = new ChildMenu();
	ChildMenu.Chung();
	ChildMenu.Chung();
	ChildMenu.Chung();
	
	
}
