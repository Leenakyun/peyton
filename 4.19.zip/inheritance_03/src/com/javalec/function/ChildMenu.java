package com.javalec.function;

public class ChildMenu extends ParentsMenu{

	private ChildMenu() {
	}
	
	public void  makeHotDoen() {
		System.out.println("얼큰 청국장");
	}
	
	public void  makeHotDoen(String str1) {
		System.out.println("얼큰 청국장");
	}
	
	
	
	
	
	
	
	
	
	@Override
	public void makeChung() {
		System.out.println("냄새 없는 청국장");
	}
	
	
}
