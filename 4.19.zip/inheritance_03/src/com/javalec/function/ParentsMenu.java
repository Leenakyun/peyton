package com.javalec.function;

public class ParentsMenu {

	private ParentsMenu() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public void makeChung() {
		System.out.println("청국장");
	}
	
	public void makeDoen() {
		System.out.println("된장국");
	}
	
	public void makeGal() {
		System.out.println("갈비찜");
	}
	
	public void makeKong() {
		System.out.println("콩비지");
	}
	
}
