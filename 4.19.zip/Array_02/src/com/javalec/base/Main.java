package com.javalec.base;

public class Main {

	public static void main(String[] args) {
		// 배열의 평균 구하기 

		int[] intNum = {1,5,8,12,200,1002};
		int tot = 0;	
		double avg = 0;
		
		for(int i=0; i<intNum.length; i++) {
			tot += intNum[i];
		}
			avg = (double)tot / intNum.length;    // 실수 적용을 위해 두곳중 한곳에 double 을 사용. 
			
			System.out.println("Average :" + avg);
		
		
		
		
		
		
		
		
		
		
	}

}
