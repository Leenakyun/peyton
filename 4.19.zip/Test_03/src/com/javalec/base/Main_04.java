package com.javalec.base;

import java.util.Scanner;

public class Main_04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		
		/*
		 * 아래의 그림과 같이 고객의 입금, 출금 및 현황을 관리하는 Program을 작성하라   단, 고객번호는 1,2,3,4,5 이다.
		 * 1. 입금
		 * 2. 출금                               입금, 출금, 현황, 종료 는 case를 활용 하면된다.
		 * 3. 현황 
		 * 4. 종료 
		 * 번호를 선택하세요 :
		 * 고객 번호 :                            고객 번호는 배열을 활용하면 된다.
		 * 금액 : 100
		 * 입금 결과 : 고객 번호 : 1 잔액 : 100
		 * --------------------------------
		 * 1. 입금
		 * 2. 출금 
		 * 3. 현황
		 * 4. 종료
		 * 번호를 선택하세요 : 1
		 * 고객 번호 : 2
		 * 금액 : 200
		 * 입급 결과 : 고객번호 : 2 잔액 : 200
		 * ---------------------------------
		 * 1. 입금
		 * 2. 출금
		 * 3. 현황
		 * 4. 종료
		 * 번호를 선택하세요 : 2
		 * 고객 번호 : 2
		 * 금액 : 500
		 * 잔액이 부족합니다!
		 * ----------------------------------
		 * 1. 입금
		 * 2. 출금 
		 * 3. 현황
		 * 4. 종료 
		 * 번호를 선택하세요!
		 *           고객명       잔액
		 *          ------     ------
		 *          1          100
		 *          2          200
		 *          3          0
		 *          4          0
		 *          5          0
		 *---------------------------------------
		 *1. 입금
		 *2. 출금 
		 *3. 현황
		 *4. 종료
		 *번호를 선택하세요! 4
		 *>>>>>>>> Thank you <<<<<<<<
		 */
		Scanner scanner = new Scanner(System.in);
		
		int[] number = new int[5];
		int customerNo = 0;
		int amount = 0;
		boolean  loop = true;
		
		while(true) {
			customerNo =0;
			amount = 0;
			System.out.println(("1. dlqrma\n2.출금\n3.현황\n4.종료"));
			System.out.print("번호를 선택하세요.");
			int act = scanner.nextInt();
		}
		
		switch(act) {
		case 1;
		System.out.println("고객 번호 :");
		customerNo = scanner.nextInt();
		System.out.print("금액 :");
		amount = scanner.nextInt();
		
		arr[customerNo -1] += amount;
		System.out.println("입금 결과 : 고객번호 :"+ customerNo + "잔액 :" + arr[customerNo-1] );
		break;
		}
		
		
		
		
		
		
		
		
		
		
		
	}

}
