package com.javalec.base;

import java.util.Scanner;

public class Main_02 {

	public static void main(String[] args) {
		// 입력할 숫자의 갯수? : 4               
		/* 4개의 숫자를 입력하세요! :             
		 * 1의 숫자 : 11                     
		 * 2의 숫자 : 22                          
		 * 3의 숫자 : 44                      
		 * 4의 숫자 : 55                      
		 * 숫자를 삽입하고자 하는 위치는 ? : 3               배열의 이동이 필요한 문제 
		 * 삽입하고자 하는 수는? : 33
		 * --------- 결과 ----------
		 * 11
		 * 22
		 * 33
		 * 44
		 * 55
		 */

		Scanner scanner = new Scanner(System.in);
		int count = 0; // 입력할 숫자의 갯수
		int search = 0; // 검색할 숫자 
		int data = 0;  // 검색 횟수 확인 
		int position = 0;   // 삽입 위치 
		int insNum = 0;   // 삽입 숫자 
		System.out.println("입력할 숫자의 갯수? : ");
		count = scanner.nextInt();
		int[] number = new int[count+1];
		
		System.out.println(count + "개의 숫자를 입력하세요! :");
		
		
		for(int i=0; i<count; i++) {
			System.out.println((i+1) + "의 숫자 :");
			number[i] =scanner.nextInt();
		}
		
		System.out.println("숫자를 삽입하고자 하는 위치 :");
		position = scanner.nextInt();
		
		System.out.println("삽입하고자 하는 숫자는? :");
		insNum = scanner.nextInt();
		
		
		for(int i = count -1; i>= position -1; i--) {
			number[i+1] = number[i];
		}
		number[position -1] = insNum;
		
		System.out.println("---------- 결과 ---------");
		
		for(int i=0; i<count+1; i++) {
			System.out.println(number[i]);
		}
		
		
		
		
		
		
		
		
		
		
	}

}
