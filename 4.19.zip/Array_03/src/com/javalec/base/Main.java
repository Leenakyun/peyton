package com.javalec.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	/*	// 구구단 출력하기 
		Scanner scanner = new Scanner(System.in);
		System.out.println();
		
		
		int[] dan = {5,3,9,7,8};
		
			
		for(int i=1; i<=9; i++) {
			for(int j=0; j<dan.length; j++) {
				System.out.print(dan[j] + "x" + i + "=" + (dan[j]*i));
			}System.out.prinln();
		}	
		
		
	*/	
		

	
/*
	

	for(int dan=2; dan<=9; dan++) {
		System.out.println("---" + dan + "단 ---");
		for(int num = 1; num<=9; num++) {
			if(num % 2 == 0)
			System.out.println(dan + "x" + num + "=" + (dan*num));
			}
		}
		*/
		
		
/*		
	String[] str = {"Sun","Mon","Tue","Wed","Thr","Fri","Sat"};
	int[] intNum = {10,20,30};
	double[] doubleNum = {1.1, 1.2};
	boolean[] booleanNum = {true, false, true, true};
*/	
	
	/*	
		// str 전체 출력해보기
	String[] str = {"Sun", "Mon", "Tue", "Wed", "Thr", "Fri", "Sat"};
	
		 for(int i=0; i<str.length; i++) {
			 System.out.println(str[i]);
		 }
	
	*/
	
/*	
	// intNum의 합계 구하기 
	int[] intNum = {10, 20, 30};
	int tot = 0;
		 for(int i=0; i<intNum.length; i++) {
			 tot += intNum[i];
		 }System.out.println("tot :"+ tot);
	
	*/	 

	/*	
		
		// doubleNum의 평균 구하기 
		double[] doubleNum = {1.1, 1.2};
		int tot = 0;
		double avg = 0;
		
		for(int i= 0; i<doubleNum.length; i++) {
			tot += doubleNum[i];
		}
		avg = tot / (double)doubleNum.length;
		System.out.println("평균 값 :" + avg);
	*/
		
		
	/*	
		// boolNum중 true의 갯수 출력하기 
	
		boolean[] booleanNum = {true, false, true, true};
		
		
	
		
	*/
		
		
		/*
		 * 5개의 숫자를 입력하세요.
		 * 1번 숫자: 10
		 * 2번 숫자: 20
		 * 3번 숫자: 30
		 * 4번 숫자: 40
		 * 5번 숫자: 50
		 * --------------------------
		 * 입력하신 숫자는 다음과 같습니다.
		 * 1) 10
		 * 2) 20
		 * 3) 30
		 * 4) 40
		 * 5) 50
		 * 합계 : 150 
		 */
		
	/*	
		int[] intNum = new int[5];
		int tot = 0;
		
		
		
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("5개의 숫자를 입력하세요 :");
		for(int i=1; i<=5; i++) {
			System.out.print(i + "번 숫자 :");
			intNum[i-1] = scanner.nextInt();
		}
		
		System.out.println("-----------------");
		
		for(int i=0; i<intNum.length; i++) {
			System.out.println((i+1) + ")" + intNum[i]);
		}
		
		for(int i=0; i<intNum.length; i++) {
			tot += intNum[i];
		}
		
		System.out.println("합계 :" + tot);
	*/	
/*		
		Scanner scanner = new Scanner(System.in);
		int [] number = new int[5];
		int total = 0;
		System.out.println("5개의 숫자를 입력하세요.");
		for(int i=0; i<number.length; i++) {
			System.out.println((i+1) + "번의 숫자:");
			number[i] = scanner.nextInt();
			total += number[i];
		}
		
		System.out.println("---------------");
		System.out.println("입력하신 숫자는 다음과 같습니다. \n");
		
		for(int i=0; i<number.length; i++) {
			System.out.println((i+1) + ")" + number[i]);
		}
		System.out.println("합계 :" + total);
	
	*/
	
		/*
		 * 입력하신 숫자는 다음과 같습니다.
		 * 5) 50
		 * 4) 40
		 * 3) 30
		 * 2) 20
		 * 1) 10
		 */
		
/*		
		Scanner scanner = new Scanner(System.in);
		int [] number = new int[5];
		int total = 0;
		System.out.println("5개의 숫자를 입력하세요.");
		for(int i=0; i<number.length; i++) {
			System.out.println((i+1) + "번의 숫자:");
			number[i] = scanner.nextInt();
			total += number[i];
		}
		
		System.out.println("---------------");
		System.out.println("입력하신 숫자는 다음과 같습니다. \n");
		
		for(int i=number.length -1; i>=0;  i--) {
			System.out.println((i+1) + ")" + number[i]);
		}
		System.out.println("합계 :" + total);
*/		
		
		/*
		 * 숫자의 갯수는 최대 100개 입니다. 몇개의 숫자를 입력하시겠습니까? 5
		 */
		
/*		
		// 숫자의 정함이 없이 무한대로 적기. 
		
		Scanner scanner = new Scanner(System.in);
		int arrayNum = 0;
		int total = 0;
		
		System.out.println("숫자의 갯수는 최대 100개 입니다. 몇개의 숫자를 입력하시겠습니까?");
			arrayNum = scanner.nextInt();
		int[] number = new int[arrayNum];
		
		System.out.println("숫자를 입력하세요.");
		for(int i=0; i<number.length; i++) {
			System.out.println((i+1) + "번의 숫자:");
			number[i] = scanner.nextInt();
			total += number[i];
		}
		
		System.out.println("---------------");
		System.out.println("입력하신 숫자는 다음과 같습니다. \n");
		
		for(int i=number.length -1; i>=0;  i--) {
			System.out.println((i+1) + ")" + number[i]);
		}
		System.out.println("합계 :" + total);
		
	*/	
		// 숫자의 갯수를 정해 나오게 하기.
		
		Scanner scanner = new Scanner(System.in);
		int arrayNum = 0;
		int total = 0;
		int[] number = new int[100];
		
		
		System.out.println("숫자의 갯수는 최대 100개 입니다. 몇개의 숫자를 입력하시겠습니까?");
		arrayNum = scanner.nextInt();
		
		if(arrayNum > 100 || arrayNum < 0) {
			System.out.println("사용 가능한 범위를 초과하였습니다.");
			return;
		}
		
		System.out.println("숫자를 입력하세요.");
		// index 시작이 0이기 때문에 0부터.
		for(int i=0; i<arrayNum; i++) {
			System.out.println((i+1) + "번의 숫자:");
			number[i] = scanner.nextInt();
			total += number[i];
		}
		
		System.out.println("---------------");
		System.out.println("입력하신 숫자는 다음과 같습니다. \n");
		
		for(int i=arrayNum -1; i>=0;  i--) {
			System.out.println((i+1) + ")" + number[i]);
		}
		System.out.println("합계 :" + total);
		
		
		
	}
	}