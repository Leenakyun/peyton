package com.javalec.function;

public class SecondSon {

	
	
	
	
	
	
	public void takeChoco() {
	
		MamaBag.choco = MamaBag.choco -1;
		if(MamaBag.choco <0) {
			System.out.println("둘째는 초고파이가 먹고 싶어요!");
		}else {
			System.out.println("둘째는 맛있게 먹었어요!");
		}
	}
	
	
	
	
	
}
