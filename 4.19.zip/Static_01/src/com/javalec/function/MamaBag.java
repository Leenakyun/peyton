package com.javalec.function;

public class MamaBag {

	public static int choco = 1;
	
	
	public MamaBag() {
		// TODO Auto-generated constructor stub
	}
	
	
	
}
