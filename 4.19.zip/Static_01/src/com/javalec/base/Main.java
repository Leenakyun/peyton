package com.javalec.base;

import com.javalec.function.FirstSon;
import com.javalec.function.SecondSon;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		FirstSon firstSon = new FirstSon();
		SecondSon secondSon = new SecondSon();
		
		firstSon.takeChoco();
		secondSon.takeChoco();
		
		
		
		
		
	}

}
