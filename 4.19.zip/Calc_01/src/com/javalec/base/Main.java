package com.javalec.base;

public class Main {

	public static void main(String[] args) {
		// 연산자
		int i = 10;
		int j = 2;
		int k = 5;
		
		// 자동 증감 연산자
		i = i + 1;
		i += 1;
		i++;   // 1씩 증가를 원한다면 ++
		
		System.out.println("증가 :" + i);
		
		i = i - 1;
		i -= 1;
		i--;
		System.out.println("감소 :" + i);
		
		// 동등 비교 관계 연산자               if 문을 쓸때 많이 사용 
		System.out.println(i == j);   // 같는지 묻는 기호는 == 
		System.out.println(i != j);   // 같지 않는지 묻는 기호는 !=
		System.out.println(i > j);
		System.out.println(i < j);
		System.out.println(i >= j);   // 크거나 같은지 묻는 기호는 >= 대소가 먼저 나와야함. 
		System.out.println(i <= j);
		// 범주형 변수 : 카테고리 분류하는것 
		
		
		// 논리 연산자(end, or)
		System.out.println((i > j) && (j > k));   // and로 묶을때는 &&  end조건은 true 두개가 나와야 true가 나옴.
		System.out.println((i > j) || (j > k));   // or로 묶을때  ||는 Shift + \을 눌러야 나옴. 
		
		// 삼항 연산자 : 간단한 비교할때 사
		System.out.println(k == 5 ? "OK" : "None");  // 문항이 3개있다고 해서 삼항 연산자라고 함     ?는 K가 5가 맞다면 실행하고 :는 k가 5가 아니라면 이걸 출력해
		System.out.println(i > 100 ? "OK" : "None"); 
		
		/*
		 7이 3의 배수인지 판단하는 문장을 작성하시오. 
		 */
		
		int s = 7;
		int u = 3;
		
		System.out.println("7이 3의 배수인가?" + ((s % 3 == 0) ? "3의 배수" : "3의 배수 아님"));
		
		String decision = (7 % 3 == 0 ? "3의 배수" : "3의 배수 아님");
		System.out.println("7이 3의 배수인가? " + decision);
		
		
	}

}
