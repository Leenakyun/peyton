package com.javalec.base;

public class Main {

	public static void main(String[] args) {
		// 묵시적 변환과 명시적 변환
		int i1 = 10;
		double d1 = i1;
		System.out.println("d1의 데이터는 " + d1 + "입니다.");

		
		double d2 = 10.0;
		int i2 = (int)d2;
		System.out.println("i2의 데이터는 " + i2 + "입니다."); // 반 내림을 하여 값을 출력 
		 //정수는 실수로 변이가 가능하지만 실수는 정수로 변이가 불가
		
		
		
	}

}
