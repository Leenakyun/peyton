package com.javalec.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
			// TODO Auto-generated method stub
		
		/*
		 *  For문 (반복문)   y = ax + b  소스에서 어떤 부분이 반복되는지 찾는것이 제일 중요. 
		 *  Matrix 행열 (엑셀)
		 *  클라스는 대문자로 변수는 소문자로 시
		 */

		// 1에서 10까지 출력 
		
		//System.out.println(1);
		//System.out.println(2);
		//System.out.println(3);
		//System.out.println(4);
		//System.out.println(5);
		//System.out.println(6);                   전역 변수
		//System.out.println(7);
		//System.out.println(8);
		//System.out.println(9);
		//System.out.println(10);
		
		
		//for(int i=1; i<=10; i++) {              // i 는 index의 약자로 서로 약속한 단어이다.  자바는 시작-최종-증가로 진행된다. 
			//System.out.println(i);               // for 문으로 간결하게 위의 소스를 간편하게 만듬. 데코 또한 가능. ("")
		//}                                       // for 문에서는 사용한 값(직역변수)은 그대로 두고 필요하다면 다른 값을 만들어 설정해야한다. 
		
		
		// 구구단 풀이 
		// 초기 (int i=1; i<=9; i++)
		//for(int i=2; i<=8; i+=2) {              // i++ 는 1개씩 증가한다는 뜻이고, i+= 뒤의 숫자만큼 배수로 올라간다는 뜻이다. 
			//System.out.println("2 x " + i + "=" + (2*i));
		//}
		
		
		// 1부터 10까지 더하기
		//int sum = 0;                   // sum은 누적 변수를 칭함. 
		//for(int i=1; i<=10; i++) {            // 누적 변수를 선언할때 for문 밖에서 선언해야한다. 
			//sum = sum + i;                    // 이콜 소스에있다면 왼쪽 값을 먼저 계산후 오른쪽으로 넘어간다.  
		//}   // 위의 소스에서 = 과 +를 간단히 +=로 표기가능 (sum += i)
		//System.out.println("1~10까지의 합계 :" + sum);
		
		// 더하기 응용 버전 및 간결화 (범위의 합계 구하기)
		
		/*int sum =0;
		int startNum = 1;
		int endNum = 10;
		
		for(int i=startNum; i<=endNum; i++) {
			sum += i;
		}
		System.out.println("합계 :");
        */
		
		
		
		// 범위 합계 
		
	/*	int sum =0;
		int startNum = 1;
		int endNum = 10;
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("첫번쨰 숫자를 입력하세요 :");
		startNum = scanner.nextInt();
		
		System.out.println("두번째 숫자를 입력하세요 :");
		endNum = scanner.nextInt();
			
		for(int i=startNum; i<=endNum; i++) {
			sum += i;
		}
		System.out.println(startNum + "~" + endNum + "합계" + sum);
	  */

		
		// 1부터 100까지의 짝수의 합계 구하기 (for 문과 if문 합치)
		
		
	/*	int evenSum = 0;
		for(int i=1; i<=100; i++) {
			if(i % 2 == 0) {
				evenSum += i;
			}
		}
		System.out.println("1부터 100까지의 짝수의 합은 " + evenSum + "입니다.");
		*/
		
		// 1부터 100까지의 홀수와 짝수의 합계 구하기 (문제)
		
		
		
		
	
	/*
	// 1부터 100까지의 수중 3의 배수이거나 5의배수인 수의 합은?
	
		int sum = 0;
		for(int i=1; i<=100; i++) {
			if((i % 3 == 0) || (i % 5 == 0)) {
				sum += i;
			}
		}
		System.out.println("1부터 100까지의 수중 3의배수이거나 5의배수인 수의 합은" + sum);
	// 무한 반복문 (whill)
	*/
	
	
		/* 범위 합계 문제 
		 * Case #1
		 * 첫번쨰 숫자를 입력하세요 : 1
		 * 두번쨰 숫자를 입력하세요 : 100
		 * 두수의 합계는 5050 입니다. 
		 * 
		 * Case #2
		 * 첫번째 숫자를 입력하세요 : 100
		 * 두번째 숫자를 입력하세요 : 1
		 * 두수의 합계는 5050 입니다.
		 */
		
	/*	
		int sum =0;
		int startNum = 0;
		int endNum = 0;
		
		
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("첫번쨰 숫자를 입력하세요 :");
		startNum = scanner.nextInt();
		
		System.out.println("두번째 숫자를 입력하세요 :");
		endNum = scanner.nextInt();
			
		if (startNum <= endNum) {
		for(int i=startNum; i<=endNum; i++) {
			sum += i;
		}else if(endNum > startNum) {
			for(int i = endNum; i<= startNum; i++) {
					sum += i;
				}
			}
		}
	}
		System.out.println(startNum + "~" + endNum + "합계" + sum);
	*/
		
		// 해답 
		// 스케너에 들어가는 숫자가 어떤것이 먼저 들어가느냐를 먼저 확인한다. (메모리가 낮을때 많이 사용.현재는 변수를 만들어 사용.)
		
		/*
		Scanner scanner = new Scanner(System.in);
		int tempStart = 0;       // 입력받은 첫번째 숫자 
		int tempEnd = 0;         // 입력받은 두번쨰 숫자 
		int startNum = 0;        // 범위 계산 첫번째 숫자 
		int endNum = 0;          // 범위 계산 두번쨰 숫자 
		int sum = 0;             // 범위의 합계 결과 
		
		
		
		
		
		System.out.println("첫번쨰 숫자를 입력하세요 :");
		tempStart = scanner.nextInt();

		System.out.println("두번째 숫자를 입력하세요 :");
		tempStart = scanner.nextInt();
		
		// 시작 숫자와 끝 숫자를 비교해서 작은수가 첫번째수로 큰수가 두번째수로 정리
		
		if(tempStart > tempEnd) {
			startNum = tempEnd;
			endNum = tempStart;
		}else {
			startNum = tempStart;
			endNum = tempEnd;
		}
		
		
		// 범위 합계 구하기 
		
		for(int i=startNum; i<= endNum; i++) {
			sum+=i;
		}
		// 출력하기 
		System.out.println("두수의 합계는 " + sum + "입니다.");
		
	
		
		
		// 문제
		/*
		 * 홀수의 합계 
		 * 짝수의 합계
		 * 합계의 평균
		 * 홀수 합계의 평균 
		 * 짝수 합계의 평균 
		 */
		
	/*	
		Scanner scanner = new Scanner(System.in);
		
		
		
		int fU = 0;
		int sum = 0;
		int evenSum = 0;
		
		System.out.println("첫수");
		sum = scanner.nextInt();
		
		System.out.println("두수");
		evenSum = scanner.nextInt();
		
		
		
		for(int i=1; i<=100; i++) {
			if(i % 2 == 0) {
				evenSum += i;
			}else if((i % 1 == 0)){
				sum += 0;
			}
		if(evenSum + sum) {
			
		}
		}
		
		
		
		
		
		
		
		System.out.println("합계 :" + fU);
		
		
		*/
		
		
		
		//  해답 
		
		Scanner scanner = new Scanner(System.in);
		int tempStart = 0;       // 입력받은 첫번째 숫자 
		int tempEnd = 0;         // 입력받은 두번쨰 숫자 
		int startNum = 0;        // 범위 계산 첫번째 숫자 
		int endNum = 0;          // 범위 계산 두번쨰 숫자 
		int sum = 0;             // 범위의 합계 결과 
		int oddSum = 0;          // 홀수의 합
		int evenSum = 0;        // 짝수의 합 
		int average = 0;
		double oddAverage = 0;
		double oddCount = 0;
		int oddCount = 0;
		double evenAverage = 0;
		double evenCount = 0;
		
		
		System.out.println("첫번쨰 숫자를 입력하세요 :");
		tempStart = scanner.nextInt();

		System.out.println("두번째 숫자를 입력하세요 :");
		tempStart = scanner.nextInt();
		
		// 시작 숫자와 끝 숫자를 비교해서 작은수가 첫번째수로 큰수가 두번째수로 정리
		
		if(tempStart > tempEnd) {
			startNum = tempEnd;
			endNum = tempStart;
		}else {
			startNum = tempStart;
			endNum = tempEnd;
		}
		
		// 범위 합계 구하기 
		
				for(int i=startNum; i<= endNum; i++) {
					sum+=i;
					if(i % 2 == 1) {
						oddSum += i;
						oddCount++;
				}else {
					evenSum += i;
					evenCount++;
				}	
				}
		

		// 평균 구하기 
		average = (double)sum / (endNum - startNum + 1);
		oddAverage = (double)oddSum /  oddCount;
		oddAverage = (double)evenSum /  evenCount;
				// 출력하기 
				System.out.println("두수의 합계는 " + sum + "입니다.");
				System.out.println("두수의 합계는 " + oddSum + "입니다.");
				System.out.println("두수의 합계는 " + evenSum+ "입니다.");
				System.out.println("두수의 합계는 " + average + "입니다.");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
}
