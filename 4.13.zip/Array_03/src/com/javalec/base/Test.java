package com.javalec.base;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
		
		/*
		 * James의 신장을 입력하세요! 170
		 * Cathy의 신장을 입력하세요! 165
		 * Kenny의 신장을 입력하세요! 180
		 * Martin의 신장을 입력하세요! 190
		 * Crystal의 신장을 입력하세요! 165
		 * --------------------------
		 * 평균 신장은: 174
		 * 가장 큰 학생은 Martin 이고 그 학생의 키는 190
		 * 가장 작은 학생은 Cathy 이고 그 학생의 키는 165
		 */
/*
		Scanner scanner = new Scanner(System.in);
		
		int sutNum = 0;
		int arrayNum = 0;
		String[] name = new String[5];
		int[] num = new int[5];
		
		String[] sutDent = {"James", "Cathy", "Kenny", "Martin", "Crystal"};
		
		for(int i=0; i<sutDent.length; i++) {
			System.out.println(sutDent[i] + "의 신장을 입력하세요!");
			sutNum = scanner.nextInt();
		}
		
		System.out.println("--------------------------");
		
		
		// 평균 값
		
		int[] intNum = {170, 165, 180, 190, 165};
		
		
	*/	
		
		
		
		
		
		
		
		Scanner scanner = new Scanner(System.in);
		String[] name = {"James", "Cathy", "Kenny", "Martin", "Crystal"};
		int[] height = new int[name.length];
		int tot =0;
		int avg = 0;
		int maxArrayNo = 0;
		int minArrayNo = 0;
		int maxHeight = 0;
		int minHeight = 1000;
		
		for(int i=0; i<name.length; i++) {
			System.out.println(name[i]+"의 신장을 입력하세요!");
			height[i] = scanner.nextInt();
			tot += height[i];
			
			if(maxHeight <= height[i]) {
				maxHeight = height[i];
				maxArrayNo = i;
			}
			if(minHeight >= height[i]) {
				minHeight = height[i];
				minArrayNo = i;
			}
		}
		
		
		avg = tot / name.length;
		
		maxHeight = height[0];
		minHeight = height[0];
		
		
		

		
		System.out.println("평균 신장은" + avg);
		System.out.println("가장 큰 학생은" + name[maxArrayNo] + "이고" + "그 학생의 키는" + height[maxArrayNo]);
		System.out.println("가장 작은 학생은" + name[minArrayNo] + "이고" + "그 학생의 키는" + height[minArrayNo]);
		
		
		
		
		
		
		
	}

}
