package com.javalec.function;

public class Cola {

	public int startNum = 0;
	public int endNum = 0;
	
	
	
	public Cola() { 
		// TODO Auto-generated constructor stub
	}
	
	
	public Cola(int startNum, int endNum) {
		super();
		this.startNum = startNum;
		this.endNum = endNum;
	
	
		adc();
	}






	private void  adc() {

	for(int i=1; i<=9; i++) {
		for(int j = startNum; j<=endNum; i++) {
			System.out.println(j + "x" + i + "=" + (j*i));
		}System.out.println();
	}
	
	
	
	
	
	}
	
}	

	

