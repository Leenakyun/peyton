package com.javalec.function;

public class Calc {

	private int firstNum = 0;
	private int secondNum = 0;
	private int result[] = ;
		
	
	public Calc() {
		// TODO Auto-generated constructor stub
	}



	public Calc(int firstNum, int secondNum) {
		super();
		this.firstNum = firstNum;
		this.secondNum = secondNum;
	
		add();
		sub();
		mul();
		div();
	}
	
	
	
	
	
	
	
	private void add() {
		System.out.println("#덧셈 :" + (firstNum + secondNum));
	}
	private void sub() {
		System.out.println("#뺄셈 :" + (firstNum - secondNum));
	}
	private void mul() {
		System.out.println("#나눗셈 :" + (String.format(("%.2f", (double)firstNum / secondNum))));
	}
	private void div() {
		System.out.println("#곱셈 :" + (firstNum * secondNum));
	}
	
	
	
	
	public String[] calc() {
		result[0] = Integer.toString(firstNum + secondNum);
		result[1] = Integer.toString(firstNum - secondNum);
		result[2] = Integer.toString(firstNum * secondNum);
		result[3] = String.format("%.2f", ((double)firstNum / secondNum));
	
		return result;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
