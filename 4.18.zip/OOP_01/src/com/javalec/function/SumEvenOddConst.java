package com.javalec.function;

public class SumEvenOddConst {

	
	// Field
	
	private int startNum;
	private int endNum;
	private int sum;
	
	
	//Constructor            디폴트를 만들고 내가쓸 것을 만들어야한다. 
	public SumEvenOddConst() {
		// TODO Auto-generated constructor stub
	}


	public SumEvenOddConst(int startNum, int endtNum) {
		super();
		this.startNum = startNum;
		this.endNum = endtNum;
	}
	
	// 합계를 구한다. 
			public int sumCalc() {
				sum = 0;
				for(int i= startNum; i<=endNum; i++) {
				sum += i;
			}
				return sum;
			}
			
			// 짝수 홀수 판단. 
			
			public String evenOdd() {
				String result = "";                                              
				if(sum % 2 ==0) {
					result = "짝수 입니다.";
				}else {
					result = "홀수 입니다.";
				} return result;
				}
	
	
	
	//Method
	
	
			/* 2개의 숫자를 입력 받아
			 * 덧셈, 뺄셈, 곱셈, 나눗셈, 결과를 실행하는 클래스를 생성하여
			 * 결과를 도출 하시오.
			 * 1) Field
			 * 2) Constructor
			 * 3) Method
			 */
			
			
			
			
			
	
	
	
	
	
	
	
	
	
	
	
}
