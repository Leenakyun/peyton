package com.javalec.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	/*	
		Scanner scanner = new Scanner(System.in);
		
		int dan = 0;
		
		System.out.println("input your number :");
		dan = scanner.nextInt();
		
		for(int i=1; i<=9; i++) {
			for(int j=dan; j>=4; j++) {
				System.out.print(dan + "x" + i+ "=" + (j*i)+ "\t");
			}System.out.println();
		}
		
		*/
		
		
		
/*		
		
		
		
		long sum = 1;        // sum의 수가 0 이면 10을 곱했을때 0이 나오기 때문에 1을 대입해준다.  long을 쓴 이유는 int일 경우에 큰 수까지의 제한이 있기 때문이다. 
		
		for(int i = 0; i<=10; i++) {
			System.out.println("10^"+ String.format("%2d", i) + "=" + String.format("%2d", sum));
			sum = sum * 10;
		}
		
*/		
		
/*		
		Scanner scanner = new Scanner(System.in);
		int decImal = 0;
		
		
		System.out.println("input your decimal no. :");
		
		decImal = scanner.nextInt();
		
		for(int i = 1; i<=decImal; i++) {       // i<=decImal이 들어가는 이유는 입력값만큼 도출하기 위함이다.
			for(int j=1; j<=i; j++) {           // j<=i의 경우 i가 들어간 이유는 위의 값을 똑같이 입력값 만큼 도출하기 위함이다.
			System.out.print("*");
		}System.out.println();
	}
		
		for(int i = decImal-1; i>=0; i--) {      // 반대로 감소하기 위해서는 decImal의 값을 -1을 하고 맨 뒤의 i의 값을 하나씩 줄여야한다.
			for(int j=1; j<=i; j++) {
				System.out.print("*");
			}System.out.println();
		}
		
		*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
