show databases;  #이 커멘트 달기위해 필요
use education;

create table prof(                        #테이블 만들기 
pcode char(4) not null primary key,
pname char(10),
pdept char(12),
pphone char(4)
);

show tables;   # 테이블을 보려면 필요한 코드 
desc professor;     # 테이블이 잘 나왔는지 확인하는 코드 
select pcode, pname, pdept, pphone, paddress from professor;   # select는 데이터를 보기위한 코드이다. (from 뒤에는 테이블 명이 들어가야한다.)
select * from professor;       # 테이블 한번에 불러오는 코드 



# 테이블에 빠진 컬럼을 추가하기 및 이름 변경 방법. 
alter table prof add paddress char(50);                  # 테이블에 컬럼 넣기 
alter table prof change paddress address char(50);       # 컬럼 이름 바꾸기 
alter table prof rename professor;                       # 테이블 이름 바꾸기 
alter table professor change address paddress char(50);  # 다시 전환 가능 
alter table professor modify pphone char(12);            # 컬럼의 글자 수 바꾸기 

# professor table에 abc란 컬럼이름과 타입은 char(5)로 추가하기 
alter table professor add abc char(5);

# 컬럼 지우는 법 (테이블 지울때도 drop)
alter table professor drop abc;

# 데이터 넣기 
insert into professor(pcode, pname, pdept, pphone, paddress)
values('p001', '김구', '컴퓨터공학과', '0001', '서울');                               # 1대1 매치로 위의 insert into에서 순서대로 적어야한다. 

insert into professor(pcode, pname, pdept, pphone, paddress)
values('p002', '안창호', '컴퓨터공학과', '0002', '수원');

select pcode, pname, pdept, pphone, paddress from professor;
select * from professor;

# 문제 )
# Table name : student.     학번 : scode char(4).  이름 : sname char(10)  학과 : sdept char(12)  전화 : sphone char(12)

show databases;
create table student(
scode char(4) not null primary key,
sname char(10),
sdept char(12),
sphone char(12)
);

insert into student(scode, sname, sdept, sphone)
values('s001', '박소명', '컴퓨터공학과', '123-4567');

insert into student(scode, sname, sdept, sphone)
values('s002', '최민국', '컴퓨터공학과', '234-5678');

insert into student(scode, sname, sdept, sphone)
values('s003', '이승호', '국문학과', '345-6789');

insert into student(scode, sname, sdept, sphone)
values('s004', '정수봉', '국문학과', '456-7890');

insert into student(scode, sname, sdept, sphone)
values('s005', '김상진', '사학과', '567-8901');

insert into student(scode, sname, sdept, sphone)
values('s006', '황정숙', '사학과', '678-9012');

select * from student;


desc student;
show tables;
drop table student;
drop table education;


