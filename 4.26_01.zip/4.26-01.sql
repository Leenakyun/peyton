use education;
desc professor;
# student table의 내용을 다보자.
select * from student;

#student에서 scode가 d001인 데이터의 이름을 james로 변경하자.
update student set sname = 'James' where scode = 'd001'; 
     # 정보를 수정하는 코드.              # 바꿀 위치 지정 (, 사용시 다른 정보도 입력 가능) (and문은 wher절에 사용된다.)
     
# sutudent에서 scord가 d001인 데이터를 삭제하자.
delete from student where scode ='d001';
#  전부 지우는 코드       # 지정위치를 꼭 적어야한다.

select * from professor where pcode = 'p001';  # 원하는 부분만 지정해서 데이터를 볼수있음. 
select pdept, paddress from professor where pcode = 'p001';

select * from professor where paddress = '서울';

# 주소가 '남도'로 끝나는 사람 찾기
select * from professor where paddress like '%남도';
                                      # like는 비슷한것  equal은 똑같은것을 찾는 코드이다. ('%'가 앞으로 오면 뒷자리부분을 찾는것, '%%' 사이에 앞뒤쪽 중에 같은것만 있어도 찾는것)
# 전체 교수 리스트를 이름 순서로 출력

select * from professor order by pname;  #(desc를 마지막에 적으면 역순으로 나온다.)
select * from professor order by pdept, pname;   # 이중 정렬 
select * from professor order by pdept, pname limit 3;  #전체 데이터중 limit란 코드를 사용하면서 몇개까지만 나오게 만드는 코드 
select * from professor where paddress = '서울'  order by pdept, pname; # 코드를 쓸때 순서가 중요하다. order by이는 거의 마지막 .

# 국문학과 교수 리스트를 이름순서로 출력

select * from professor where pdept ='국문학과' order by pname;

# 전체 교수 리스트 중 이름만 역순으로 3명만 출력하기 

select * from professor order by pname desc limit 3;

select pname from professor order by pname desc limit 3;    # 이름만 나오게 하라는 말이였다.... 

select * from student;

# scode가 s001인 사람의 이름을 박수명으로 수정하기 
update student set sname ='박수명' where scode = 's001';

# 이름이 박수명인 사람의 전공을 수학과로, 전화번호를 123-1234로 수정하기.
update student set sdept = '수학과', sphone = '123-1234' where sname = '박수명';

# 학번이 s001인 사람의 이름을 박소명, 전화번호는 123-4657, 전공은 컴퓨터공학과로 변경
update student set sname = '박소명', sdept = '컴퓨터공학과', sphone = '123-4567' where scode = 's001';

#
select * from professor;
select * from professor where paddress = '강원도' and pdept = '국문학과';   #()를 사용하면 and, or을 동시에 사용가능.

select * from professor where paddress = '강원도' or pdept = '국문학과';   #  or은 두가지 조건중 하나만 만족하면 됨. 

select count(*) from professor where paddress = '강원도' and pdept = '국문학과';    # 조건에 만족한 데이터의 갯수를 세어줌.

select 10 + 30;  # 사칙연산 가능

# course

select * from course;

# 강의 시간이 2인 과목들의 강의 시간을 한시간 증가시키고 강의실을 Lab1으로 변경하기.

update course set ctime = ctime + 1, croom = 'Lab1' where ctime = 2;   # 숫자는 ''을 사용하지 않는다. 

# 성이 김씨인 교수님들을 출력하시오.
select * from professor where pname like '%김%';

# MySQL 과목을 강의하는 교수님의 이름, 전화번호, 강의실을 검색하는 문장을 작성하시오.
# Table Name : professor, course, lecture

select p.pname, p.pphone, c.croom
from professor as p, course as c, lecture as l             # 코드가 길어지면 as(약칭) 을 사용하여 간단하게 만들수있음.
where c.cname = 'MYSQL' and
c.ccode = l.lccode and l.lpcode = p.pcode;                                 # 조건 

# 김구 교수님이 강의하는 과목명, 강의시간과 강의실을 출력하시오.


select p.pname as '교수명', c.cname as '과목명', c.ctime as'강의시간', c.croom as '강의실'.     # as 생략가능. 
from professor as p, lecture as l, course as c
where p.pname ='김구' and
c.ccode = l.lccode and p.pcode =l.lpcode;          # where에서 이부분을 먼저 쓰는것이 좋다.


# 각 학생이 수강 신청한 과목에 대해서 학생이름, 과목명, 강의실, 강의시간을 검색하는 문장 작성하기

select s.sname, c.cname, c.croom, c.ctime
from student as s, course as c, register as r
where c.ccode = r.rccode and s.scode = r.rscode      # 여기까지 잘썻는데... 조건을 안넣어도 된다니...
and s.sname = '박소명';                              







