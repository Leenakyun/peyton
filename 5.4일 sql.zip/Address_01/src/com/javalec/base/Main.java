package com.javalec.base;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.text.DefaultEditorKit.InsertBreakAction;

import com.javalec.dao.Dao;
import com.javalec.dto.Dto;

import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.ListSelectionModel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Main extends JFrame {

	private JPanel contentPane;
	private JRadioButton rbInsert;
	private JRadioButton rbUpdate;
	private JRadioButton rbDelete;
	private JRadioButton rbQuery;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JComboBox cbSelection;
	private JTextField tfSelection;
	private JButton btnQuery;
	private JScrollPane scrollPane;
	private JTable innerTable;
	private JLabel lblNewLabel;
	private JTextField tfSeqno;
	private JTextField tfName;
	private JLabel lblNewLabel_1;
	private JTextField tfTelno;
	private JLabel lblNewLabel_2;
	private JTextField tfAddress;
	private JLabel lblNewLabel_3;
	private JTextField tfEmail;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_4_1;
	private JTextField tfRelation;
	private JButton btnOk;
	private JLabel lblNewLabel_5;
	private JTextField tfCount;

	
	// Table
	
	private final DefaultTableModel outerTable = new DefaultTableModel();
	String message = ""; 
	
	
	
	
	
	
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				tableInit();
				searchAction();
				screenPartition();
				
			}
		});
		setTitle("주소록");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 512);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getRbInsert());
		contentPane.add(getRbUpdate());
		contentPane.add(getRbDelete());
		contentPane.add(getRbQuery());
		contentPane.add(getCbSelection());
		contentPane.add(getTfSelection());
		contentPane.add(getBtnQuery());
		contentPane.add(getScrollPane());
		contentPane.add(getLblNewLabel());
		contentPane.add(getTfSeqno());
		contentPane.add(getTfName());
		contentPane.add(getLblNewLabel_1());
		contentPane.add(getTfTelno());
		contentPane.add(getLblNewLabel_2());
		contentPane.add(getTfAddress());
		contentPane.add(getLblNewLabel_3());
		contentPane.add(getTfEmail());
		contentPane.add(getLblNewLabel_4());
		contentPane.add(getLblNewLabel_4_1());
		contentPane.add(getTfRelation());
		contentPane.add(getBtnOk());
		contentPane.add(getLblNewLabel_5());
		contentPane.add(getTfCount());
	}
	private JRadioButton getRbInsert() {
		if (rbInsert == null) {
			rbInsert = new JRadioButton("입력");
			rbInsert.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					screenPartition();
				}
			});
			buttonGroup.add(rbInsert);
			rbInsert.setBounds(16, 17, 72, 23);
		}
		return rbInsert;
	}
	private JRadioButton getRbUpdate() {
		if (rbUpdate == null) {
			rbUpdate = new JRadioButton("수정");
			rbUpdate.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					updateAction();
					screenPartition();
				}
			});
			buttonGroup.add(rbUpdate);
			rbUpdate.setBounds(75, 17, 72, 23);
		}
		return rbUpdate;
	}
	private JRadioButton getRbDelete() {
		if (rbDelete == null) {
			rbDelete = new JRadioButton("삭제");
			rbDelete.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					screenPartition();
					
				}
			});
			buttonGroup.add(rbDelete);
			rbDelete.setBounds(132, 17, 72, 23);
		}
		return rbDelete;
	}
	private JRadioButton getRbQuery() {
		if (rbQuery == null) {
			rbQuery = new JRadioButton("검색");
			rbQuery.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					screenPartition();
				}
			});
			rbQuery.setSelected(true);
			buttonGroup.add(rbQuery);
			rbQuery.setBounds(184, 17, 72, 23);
		}
		return rbQuery;
	}
	private JComboBox getCbSelection() {
		if (cbSelection == null) {
			cbSelection = new JComboBox();
			cbSelection.setModel(new DefaultComboBoxModel(new String[] {"이름", "주소", "관계"}));
			cbSelection.setBounds(16, 56, 72, 27);
		}
		return cbSelection;
	}
	private JTextField getTfSelection() {
		if (tfSelection == null) {
			tfSelection = new JTextField();
			tfSelection.setBounds(85, 55, 273, 26);
			tfSelection.setColumns(10);
		}
		return tfSelection;
	}
	private JButton getBtnQuery() {
		if (btnQuery == null) {
			btnQuery = new JButton("검색");
			btnQuery.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					conditionQuery();
				}
			});
			btnQuery.setBounds(355, 55, 72, 29);
		}
		return btnQuery;
	}
	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setBounds(26, 95, 401, 135);
			scrollPane.setViewportView(getinnerTable());
		}
		return scrollPane;
	}
	private JTable getinnerTable() {
		if (innerTable == null) {
			innerTable = new JTable();
			innerTable.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					tableClick();
				}
			});
			innerTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			innerTable.setModel(outerTable);
		}
		return innerTable;
	}
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("Seq No :");
			lblNewLabel.setBounds(36, 236, 61, 16);
		}
		return lblNewLabel;
	}
	private JTextField getTfSeqno() {
		if (tfSeqno == null) {
			tfSeqno = new JTextField();
			tfSeqno.setEditable(false);
			tfSeqno.setHorizontalAlignment(SwingConstants.TRAILING);
			tfSeqno.setBounds(109, 231, 48, 26);
			tfSeqno.setColumns(10);
		}
		return tfSeqno;
	}
	private JTextField getTfName() {
		if (tfName == null) {
			tfName = new JTextField();
			tfName.setEditable(false);
			tfName.setColumns(10);
			tfName.setBounds(109, 272, 130, 26);
		}
		return tfName;
	}
	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("이름 :");
			lblNewLabel_1.setBounds(36, 277, 61, 16);
		}
		return lblNewLabel_1;
	}
	private JTextField getTfTelno() {
		if (tfTelno == null) {
			tfTelno = new JTextField();
			tfTelno.setEditable(false);
			tfTelno.setColumns(10);
			tfTelno.setBounds(109, 312, 157, 26);
		}
		return tfTelno;
	}
	private JLabel getLblNewLabel_2() {
		if (lblNewLabel_2 == null) {
			lblNewLabel_2 = new JLabel("전화번호 :");
			lblNewLabel_2.setBounds(36, 317, 61, 16);
		}
		return lblNewLabel_2;
	}
	private JTextField getTfAddress() {
		if (tfAddress == null) {
			tfAddress = new JTextField();
			tfAddress.setEditable(false);
			tfAddress.setColumns(10);
			tfAddress.setBounds(109, 351, 239, 26);
		}
		return tfAddress;
	}
	private JLabel getLblNewLabel_3() {
		if (lblNewLabel_3 == null) {
			lblNewLabel_3 = new JLabel("주소 :");
			lblNewLabel_3.setBounds(36, 356, 61, 16);
		}
		return lblNewLabel_3;
	}
	private JTextField getTfEmail() {
		if (tfEmail == null) {
			tfEmail = new JTextField();
			tfEmail.setEditable(false);
			tfEmail.setColumns(10);
			tfEmail.setBounds(109, 389, 157, 26);
		}
		return tfEmail;
	}
	private JLabel getLblNewLabel_4() {
		if (lblNewLabel_4 == null) {
			lblNewLabel_4 = new JLabel("전자우편 :");
			lblNewLabel_4.setBounds(36, 394, 61, 16);
		}
		return lblNewLabel_4;
	}
	private JLabel getLblNewLabel_4_1() {
		if (lblNewLabel_4_1 == null) {
			lblNewLabel_4_1 = new JLabel("관계 :");
			lblNewLabel_4_1.setBounds(36, 433, 61, 16);
		}
		return lblNewLabel_4_1;
	}
	private JTextField getTfRelation() {
		if (tfRelation == null) {
			tfRelation = new JTextField();
			tfRelation.setEditable(false);
			tfRelation.setColumns(10);
			tfRelation.setBounds(109, 428, 130, 26);
		}
		return tfRelation;
	}
	private JButton getBtnOk() {
		if (btnOk == null) {
			btnOk = new JButton("OK");
			btnOk.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					actionPartition();
				}
			});
			btnOk.setEnabled(false);
			btnOk.setBounds(310, 442, 117, 29);
		}
		return btnOk;
	}
	private JLabel getLblNewLabel_5() {
		if (lblNewLabel_5 == null) {
			lblNewLabel_5 = new JLabel("Count :");
			lblNewLabel_5.setBounds(279, 236, 61, 16);
		}
		return lblNewLabel_5;
	}
	private JTextField getTfCount() {
		if (tfCount == null) {
			tfCount = new JTextField();
			tfCount.setEditable(false);
			tfCount.setHorizontalAlignment(SwingConstants.TRAILING);
			tfCount.setBounds(341, 231, 72, 26);
			tfCount.setColumns(10);
		}
		return tfCount;
	}
	
	
	
	//----------------------------Function
	
	
	//  화면의 Table 정리 
	private void tableInit(){
		outerTable.addColumn("순서");
		outerTable.addColumn("이름");
		outerTable.addColumn("전화번호");
		outerTable.addColumn("관계");
		outerTable.setColumnCount(4);
		
		int i = outerTable.getRowCount();
		for(int j = 0; j > i; j++) {
			outerTable.removeRow(0);
		}
		
		innerTable.setAutoResizeMode(innerTable.AUTO_RESIZE_OFF);
		
		int vColIndex = 0;
		TableColumn col = innerTable.getColumnModel().getColumn(vColIndex);
		int width = 30;
		col.setPreferredWidth(width);
		
		vColIndex = 1;
		col = innerTable.getColumnModel().getColumn(vColIndex);
		width = 100;
		col.setPreferredWidth(width);
		
		vColIndex = 2;
		col = innerTable.getColumnModel().getColumn(vColIndex);
		width = 100;
		col.setPreferredWidth(width);
		
		vColIndex = 3;
		col = innerTable.getColumnModel().getColumn(vColIndex);
		width = 200;
		col.setPreferredWidth(width);
		
	}
	
	
	
	
	
	
	
	
	
	// DB의 Table에서 화면의 Table에 들어갈 정보 가져오기 
	private void searchAction(){
		Dao dao = new Dao();
		ArrayList<Dto> dtoList = dao.selectList();
		int listCount = dtoList.size();
		
		for(int i = 0; i < listCount; i++) {
			String temp = Integer.toString(dtoList.get(i).getSeqno());
			String[] qTex = {temp, dtoList.get(i).getName(), dtoList.get(i).getTelno(), dtoList.get(i).getRelation()};
			outerTable.addRow(qTex);
		}
		tfCount.setText(Integer.toString(listCount));
	}
	
	
	private void screenPartition() {
		// 검색의 경우
		if(rbQuery.isSelected()) {
			tfName.setEditable(false);
			tfTelno.setEditable(false);
			tfAddress.setEditable(false);
			tfEmail.setEditable(false);
			tfRelation.setEditable(false);
			btnOk.setVisible(false);
		}
		
		
		
		
		// 입력의 경우
		
		if(rbInsert.isSelected()) {
			tfName.setEditable(true);
			tfTelno.setEditable(true);
			tfAddress.setEditable(true);
			tfEmail.setEditable(true);
			tfRelation.setEditable(true);
			btnOk.setVisible(true);
			btnOk.setEnabled(true);
			
			
		}
		
		// 수정이나 삭제일 경우 
		if(rbUpdate.isSelected() || rbDelete.isSelected()) {
			tfName.setEditable(false);
			tfTelno.setEditable(false);
			tfAddress.setEditable(false);
			tfEmail.setEditable(false);
			tfRelation.setEditable(false);
			btnOk.setVisible(true);
			btnOk.setEnabled(false);
		}
		
	}
	
	private void tableClick() {
		
		// 수정일때 키값 
		if(rbUpdate.isSelected()) {
			tfName.setEditable(true);
			tfTelno.setEditable(true);
			tfAddress.setEditable(true);
			tfEmail.setEditable(true);
			tfRelation.setEditable(true);
			btnOk.setVisible(true);
			btnOk.setEnabled(true);
		}
		
		
		// 삭제일 때 키값 
		if(rbDelete.isSelected()) {
			tfName.setEditable(false);
			tfTelno.setEditable(false);
			tfAddress.setEditable(false);
			tfEmail.setEditable(false);
			tfRelation.setEditable(false);
			btnOk.setVisible(true);
			btnOk.setEnabled(true);
		}
		
		
		int i = innerTable.getSelectedRow();
		String wkSequence = (String)innerTable.getValueAt(i,0);
		
		int wkSeqno = Integer.parseInt(wkSequence);
		
		// Dao에 의뢰한다.
		Dao dao = new Dao(wkSeqno);
		Dto dto = dao.tableClick();
		
		tfSeqno.setText(Integer.toString(dto.getSeqno()));
		tfName.setText(dto.getName());
		tfTelno.setText(dto.getTelno());
		tfAddress.setText(dto.getAddress());
		tfEmail.setText(dto.getEmail());
		tfRelation.setText(dto.getRelation());
	}
	
	
	
	
	private void actionPartition() {
		// 입력인 경우
		
		if(rbInsert.isSelected()) {
			int i_chk = insertFieldCheck();
			if(i_chk == 0) {
				insertAction();
				tableInit();
				searchAction();
				clearColumn();
				
		}else {
			JOptionPane.showMessageDialog(this, "주소록 정보 입력!\n" + message + "확인하세요.", "주소록 정보", JOptionPane.INFORMATION_MESSAGE); 
		}
		}
	}
		private int insertFieldCheck() { 		
			int i = 0; 
					
			
			if (tfName.getText().trim().length() == 0) { 		
				i++ ; 		
				message = "이름을 ";
				tfName.requestFocus(); 		
			}
			if (tfTelno.getText().trim().length() == 0) {
				i++ ;
				message = "전화번호를 ";
				tfTelno.requestFocus();
			}
			
			if (tfAddress.getText().trim().length() == 0) {
				i++ ;
				message = "주소를 ";
				tfAddress.requestFocus();
			}
			
			if (tfEmail.getText().trim().length() == 0) {
				i++ ;
				message = "전자우편을 ";
				tfEmail.requestFocus();
			}
			
			if (tfRelation.getText().trim().length() == 0) {
				i++ ;
				message = "관계를 ";
				tfRelation.requestFocus();
			}
			
			return i; 		 
		}
	
		private void insertAction() {
			String name = tfName.getText();
			String telno = tfTelno.getText();
			String address = tfAddress.getText();
			String email = tfEmail.getText();
			String relation = tfRelation.getText();
			
			Dao dao = new Dao(name, telno, address, email, relation);
			boolean result = dao.insertAction();
			
			if(result) {
				JOptionPane.showMessageDialog(this,"주소록 정보 입력!\n" + tfName.getText(), "님의 정보가 입력 되었습니다.", JOptionPane.INFORMATION_MESSAGE);
					
				}else {
					JOptionPane.showMessageDialog(this,"주소록 정보 입력!\n" + "입력중 문제가 발생하였습니다. \n관리자에게 문의하세요.", "Error",JOptionPane.INFORMATION_MESSAGE);
				}
			 
			
			
		
			
			
			
			
			
			
		if(rbUpdate.isSelected()) {
			int i_chk = insertFieldCheck();
			if(i_chk == 0) {
				
				insertAction();
				tableInit();
				searchAction();
				clearColumn();
			}
		}
		}
	/*	
		
		if(rbDelete.isSelected()) {
				
				deleteAction();
				tableInit();
				searchAction();
				clearColumn();
			}
		}
		}
		*/
		
		if(rbD)
		
		
		
		
		
		
		private void updateAction() {
			
			String name = tfName.getText();
			String telno = tfTelno.getText();
			String address = tfAddress.getText();
			String email = tfEmail.getText();
			String relation = tfRelation.getText();
			int seqno = Integer.parseInt(tfSeqno.getText());
			
			Dao dao = new Dao(name, telno, address, email, relation);
			boolean result = dao.updateAction(); 
			
			if(result) {
				JOptionPane.showMessageDialog(this,"주소록 정보 입력!\n" + tfName.getText(), "님의 정보가 수 되었습니다.", JOptionPane.INFORMATION_MESSAGE);
					
				}else{
					JOptionPane.showMessageDialog(this,"주소록 정보 입력!\n" + "입력중 문제가 발생하였습니다. \n관리자에게 문의하세요.", "Error",JOptionPane.INFORMATION_MESSAGE);
				}
			
		}
		
		
		
		private void delectAction() {
			
			int seqno = Integer.parseInt(tfSeqno.getText());
			
			Dao dao = new Dao(seqno);
			boolean result = dao.delectAction(); 
			
			if(result) {
				JOptionPane.showMessageDialog(this,"주소록 정보 입력!\n" + tfName.getText(), "님의 정보가 삭제 되었습니다.", JOptionPane.INFORMATION_MESSAGE);
					
				}else{
					JOptionPane.showMessageDialog(this,"주소록 정보 입력!\n" + "입력중 문제가 발생하였습니다. \n관리자에게 문의하세요.", "Error",JOptionPane.INFORMATION_MESSAGE);
				}
			
		}
		}
		
		

		
		
		private void clearColumn() {
			tfSeqno.setText("");
			tfName.setText("");
			tfTelno.setText("");
			tfAddress.setText("");
			tfEmail.setText("");
			tfRelation.setText("");
		}
	
		
		conditionQuery();
		
		private void conditionQuery() {
			int i = cbSelection.getSelectedIndex();
			String conditionQueryColumn = "";
			
			switch(i) {
			case 0:
				conditionQueryColumn ="name";
				break;
			case 1:
				break;
				conditionQueryColumn = "address";
				break;
			case 2:
				conditionQueryColumn = "relation";
				break;
			default:
				break;
		
			}
			tableInit();
			clearColumn();
			conditionQueryAction(conditionQueryColumn);
		}
		
		private void conditionQueryAction(String conditionQueryColumn) {
			Dao dao = new Dao();
			ArrayList<Dto> dtoList = dao.selectList();
			int listCount = dtoList.size();
			
			for(int i = 0; i < listCount; i++) {
				String temp = Integer.toString(dtoList.get(i).getSeqno());
				String[] qTex = {temp, dtoList.get(i).getName(), dtoList.get(i).getTelno(), dtoList.get(i).getRelation()};
				outerTable.addRow(qTex);
			}
			tfCount.setText(Integer.toString(listCount));
		}
			
		
		
		
		
		
		
		
	
}// End
