package com.javalec.util;

public class Sharevar {

	public static final String DBName = "jdbc:mysql://127.0.0.1/useraddress?serverTimezone=UTC&characterEncoding=utf8&useSSL=FALSE" ;
	public static final String DBUser = "root" ;
	public static final String DBPass = "qwer1234";
	
	
	
	
	
	
	
	
	
	
	
	
	
}
