use shopping;

show databases;
show tables;

create table customer(
cuserid char(10) not null primary key
cphone char(10),
cname char(5),
cpassword char(10)
);

create table customer(
cuserid char(4) not null primary key,
cphone char(10),
cname char(12),
cpassword char(12)
);

create table thing(
tpriductid char(4) not null primary key,
tname char(10),
tinventory char(12),
tmount char(12),
treceiving char(10)
);

