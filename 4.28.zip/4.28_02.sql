use education;
 select * from course;
 select sum(ctime) from course;    # 합칠(+) 갯수가 적으면 sum으로 지정해서 작업하는것이 좋다. 
 select avg(ctime) from course;    # 평균 
 select count(*) from course;      # 프라임키를 ()안에 적어도 되고 *은 행의갯수를 뜻한다.  컬럼의 갯수가 많다면 *로 지정하는것 보다 프라임키를 사용하는게 좋다.
 
 
 # 학생이름별 전공별 신청한 총 학점을 출력

 select s.sname, s.sdept, c.ctime 
 from student s, course c, register r
 where s.scode = r. rscode and c.ccode = r.rccode
 ;
 
 
  select s.sname, s.sdept, sum(c.ctime) 
 from student s, course c, register r
 where s.scode = r. rscode and c.ccode = r.rccode
 group by s.sname, sdept;
 
 
 # 각 학과별 교수님은 몇분?
 
 select pdept, count(pcode)     #  select 학과별  count할곳을 지정할때 (프라임키)를 사용한다.
 from professor                 #  어디서
 group by pdept;                # 어느 부분을 그룹으로 만들지 
 
 
 select distinct(pdept)        #  distinct 많이 팔리는 물건, 동명이인 (유니크한 값)찾기 등등 사용할때 많이 쓴다.
 from professor;
 

select now()                   # 일자 시간을 알기 위한 함수 



 
