SELECT * FROM shopping.product;

# 제품정보에서 nike의 제품명을 나이키 화이트 에어, 재고량을 30개로 수정하기

use shopping;

select * from product;

update product set pname = '나이키 화이트 에어', pstock = 30 where productid = 'nike';

# 제품명 proSpecs의 가격을 100000으로 수정하기 
update product set pprice = 100000 where productid = 'proSpecs';

# proSpecs의 재고를 50개 추가하고 현재일자로 입고 시키기

update product set pstock = pstock + 50, insertdate = now() where productid = 'proSpecs';


select * from customer;
#id가 jangbee이고 password를 1111 이라고 입력 하였을 경우
#해당 id를 check하는 SQL 문장은?

select count(*)
from customer
where userid = 'jangbee' and password ='2345';      # 로그인 시 맞는 아이디인지 아니닌지 확인 가능한 부분


# 유비가 현재일자에 nike제품을 5개 구매했다.
insert into purchase (userid, probuctid ,insertdate, qty)
values ('yubee', 'nike', now(), 5);

# 팔린 재고 -하기 
update product set pstock = pstock - 5, insertdate = now() where productid = 'nike';

#유비가 현재일자에 proSpecs을 5개 구매했다.
insert into purchase (userid, probuctid ,insertdate, qty)
values ('yubee', 'proSpecs', now(), 5);
update product set pstock = pstock - 5, insertdate = now() where productid = 'proSpecs';
#유비가 현재일자에 newbalance제품을 5개 구매했다.
insert into purchase (userid, probuctid ,insertdate, qty)
values ('yubee', 'newBalance', now(), 5);
update product set pstock = pstock - 5, insertdate = now() where productid = 'newBalance';

#장비가 현재일자에 nike제품을 10개 구매했다.
insert into purchase (userid, probuctid ,insertdate, qty)
values ('jangbee', 'nike', now(), 10);
update product set pstock = pstock - 10, insertdate = now() where productid = 'nike';

#장비가 현재일자에 newBalance제품을 5개 구매했다.
insert into purchase (userid, probuctid ,insertdate, qty)
values ('jangbee', 'newBalance', now(), 5);
update product set pstock = pstock - 5, insertdate = now() where productid = 'newBalance';

#관우가 현재일자에 newBalance제품을 5개 구매했다.
insert into purchase (userid, probuctid ,insertdate, qty)
values ('kwanwoo', 'newBalance', now(), 5);
update product set pstock = pstock - 5, insertdate = now() where productid = 'newBalance';


# 고객 ID별 높은 매출 금액순으로 출력하기.    높은 매출,
select c.name, sum(d.pprice * p.qty)
from customer c ,purchase p, product d 
where c.userid = p.userid and d.productid = p.probuctid
group by c.name
o;



# 제품별 높은 매출 금액순으로 출력하기 
select
from
where
order by


