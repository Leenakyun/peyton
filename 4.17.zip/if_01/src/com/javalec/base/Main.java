package com.javalec.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// Condition
// 선언 부		
		int i = 10, j = 20, k = 10;
		// 대문자로 시작하여서 Packge에서 복사해옴. (내가 아닌 다른사람이 짠 소슬르 가저올때 사용됨.)
	
// 입력 부분 
		Scanner scanner = new Scanner(System.in);
		String str1 = new String("abc");   // 원래는 이렇게 사용되는 함수지만 String str1 = ("adb")로 축약 가능하다.
		// int 뒤에 붙는 i, j ,k        scanner 같은 함수
		System.out.print("i의 값을 입력해 주세요! : ");
		i = scanner.nextInt();    // 선언문은 중간이 아닌 위쪽에 자리 잡는것에 깔끔하고 기독성이 있다.
			System.out.print("j의 값을 입력해 주세요! : ");
		j = scanner.nextInt();   
			System.out.print("k의 값을 입력해 주세요! : ");
		k = scanner.nextInt();    
		
		
// 출력 부분 		
    // 스코프 {} 는 꼭 잘 적어야한다. 
		if(j > i) {
			System.out.println("j가 i보다 큽니다.");
		}else if(j > i) {
			System.out.println("j가 i보다 작습니다.");
		}else {
			System.out.println("j와 i는 같습니다.");
		
		}
		// 이어지는 조건이라면 else if 를 사용 해야하고 또다른 if를 사용 해야한다면 다른 줄에 사용해야한다. 
		
		
		
		
		
		if(j < k) {
			System.out.println("j와 k가 작습니다.");
		}else if(j > k) {
			System.out.println("j가 k보다 큽니다.");
		}else {
			System.out.println("i가 k와 같습니다.");
		}
		
		
		
		System.out.println("---End---");
		
	}

}
