package com.javalec.base;

public class Main {

	public static void main(String[] args) {
		// 변수
		int num1 = 20;
		int num2 = 10;
		
		int num3;
		num3 = num1 + num2;   // 이렇게 쓰기 싫다면 생성할때 넣기
		
		char char1 = 'A';
		char char2 = '가';
		
		String str1 = "대한민국";
		
		double dNum1 = 10.123   // 자바 타입중에서 메모리를 제일 적게 차지한다. (1이 true 0가 false)
		boolean boolNum2 = false;
		
		System.out.println(num1);
		System.out.println(num3);
		System.out.println(char1);
		System.out.println(char2);
		System.out.println(str1);
		System.out.println(dNum1);
		System.out.println(boolNum1);
		System.out.println(boolNum2);
		
		// 기본자료형 java 언어에 이미 존재하고 있는 data type 간단한 data들의 형태. ex. int, double, char
		// 여러가지 data들이 모여있는 복잡한 data type 기본 자료형에 비해 크기가 크다. ex. String, System, ArrayList
		

	}

}
