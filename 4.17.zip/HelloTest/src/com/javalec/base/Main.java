package com.javalec.base;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// str를 사용하는 것을 "선언문"이라고 한다.
		String nationKorea = "대한민국";
		String nationEnglish = "Korea";
		String fruits = "\nApple\t사과\nBanana\t바나나";
		
		
		// 출력문 
		System.out.println("**" + nationKorea + "**" + fruits);   
		// 한 코드에 +를 사용하여 적용하면 기독성이 올라감, 꾸미기를 위한 것은 코드에 붙여서 깔끔하게한다. 
		System.out.println();      // 한줄 띄어쓸때 해당 코드를 집어넣어 기독성있게 한줄띄기 
		System.out.println("**" + nationEnglish + "**" + fruits);
		System.out.println();   // 공통적인 부분을 하나씩 나누어 적용
	}

}
