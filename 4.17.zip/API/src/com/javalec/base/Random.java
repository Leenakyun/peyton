package com.javalec.base;

public class Random {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
