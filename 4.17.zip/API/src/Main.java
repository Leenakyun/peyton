
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
 * scanner, string 등 대문자로 시작하는 문법은 클레스다. 
 * 
 */
		
		
		
		
		
		
		
	}

}
