package com.javalec.base;

import java.util.Scanner;

public class Main_01 {

	public static void main(String[] args) {
		// 몇 개의 숫자를 입력 할지 결정한 후 숫자를 입력하고 이중 검색을 원하는 숫자의 위치를 파악.
		/*
		 * 입력할 숫자의 갯수? : 4               입력할 숫자의 갯수? : 4
		 * 4개의 숫자를 입력하세요! :             4개의 숫자를 입력하세요! :
		 * 1의 숫자 : 11                      1의 숫자 : 11
		 * 2의 숫자 : 22                      2의 숫자 : 22
		 * 3의 숫자 : 33                      3의 숫자 : 33
		 * 4의 숫자 : 44                      4의 숫자 : 44
		 * 검색할 숫자는 ? : 33                검색할 숫자는? : 55
		 * 33의 위치는 3번째 입니다.             55는 존재하지 않습니다. 
		 */

		
		Scanner scanner = new Scanner(System.in);
		int count = 0; // 입력할 숫자의 갯수
		int search = 0; // 검색할 숫자 
		int data = 0;  // 검색 횟수 확인 
		
		
		System.out.print("입력할 숫자의 갯수? : ");
		count = scanner.nextInt();
		int[] number = new int[count];
		
		System.out.println(count + "개의 숫자를 입력하세요! :");
		
		// 배열에 입력할 숫자 넣기 
		
		for(int i=0; i<count; i++){
				System.out.print((i+1) + "의 숫자	 :");
				number[i] = scanner.nextInt();
		}
		
		// 검색
		System.out.println("검색할 숫자는? :");
		search = scanner.nextInt();
		
		for(data=0; data<count; data++) {
			if(number[data] == search) {
				System.out.println(search + "의 위치는" + (data+1) + "번째 입니다.");
				break;
			}
		}
		
		// 찾지 못하는 경우
		
		if(data == count) {
			System.out.println(search + "는 존재하지 않습니다.");
		}
		
		// end 
		
		
		
		// 
		
		
		
	}

}
