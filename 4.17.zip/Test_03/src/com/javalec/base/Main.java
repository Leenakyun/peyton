package com.javalec.base;

import java.util.Scanner;

public class Main {

	private static int i;

	public static void main(String[] args) {
		// 10개의 점수(0점 부터 99점)를 입력받아 점수의 분포를 10점 간격의 등급으로 된 히스토크램을 표시해라.
		/*
		 * input score :
		 * 1의 score : 34
		 * 2의 score : 32
		 * 3의 score : 55
		 * 4의 score : 57
		 * 5의 score : 59
		 * 6의 score : 53
		 * 7의 score : 90
		 * 8의 score : 99
		 * 9의 score : 88
		 * 10의 score : 12
		 * --------------- Histogram -----------
		 * 90 : ##
		 * 80 : #
		 * 70 :
		 * 60 :
		 * 50 : ####                         위의 숫자 중에 50은 4개 90은 2개 30은 2개 80은 1개 10은 1개를 표시하는 규칙이있다. 
		 * 40 :                              즉 10의 단위에서 위쪽의 속한 숫자가 어디에 속하는지 표시 .
		 * 30 : ##
		 * 20 :
		 * 10 : #
		 * 0  :
		 */
	
	Scanner scanner = new Scanner(System.in);
	int[] histo = new int[10];

	
	
	
	
/*	
	
	// 입력 
	System.out.println("intput Score :");
	for(int i=0; i<histo.length; i++);{
		System.out.println((i+1) + "의 score :");
		histo[scanner.nextInt()/10]++;
	}
		scanner.close();
	
	// 출력 
		
		System.out.println("----------histogram------------");
		
		for(int i=(histo.length -1); i>=0; i--);{
			System.out.println(String.format("%3d", i*10));
			for(int j =1; j<=histo[i]; j++);
			System.out.println("#");
		}
		
			System.out.println();
		
	*/	
	// 배열을 사용하여 위의 코드를 변경해보기. 
	
		//입력		
				
			System.out.println("input Score :");	
				
			for(int i=0; i<histo.length; i++) {
				System.out.println((i + 1) + "의 score :");
				histo[scanner.nextInt()/10]++;
			}
				scanner.close();
				
		// 츨력 		
			System.out.println("--------------histogram------------");
			
			for(int i=(histo.length -1); i>=0; i--);{
				System.out.println(String.format("%3d : ",  i* 10));
				for(int j=1; j <= histo[i]; j++);
				System.out.println("#");
			}
		
				
				
	}

}
