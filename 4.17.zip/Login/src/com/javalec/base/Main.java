package com.javalec.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		String id = "";
		String passwd = "";
		
		System.out.println("** Log in Check **");
		
		System.out.println("User ID");
		id = scanner.next();
				
		System.out.println("User ID"); {
		passwd = scanner.next();
		
		if(id.equals("root") && passwd.equals("1234")) {        // 문자열을 코딩할때에는 꼭 equals를 사용해야한다. 
			System.out.println("환영합니다.");
		}else {
			System.out.println("등록된 사용자가 아닙니다.");
		}
		
		
		
	}

}
}
