package com.javalce.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		Scanner scanner = new Scanner(System.in);
		int pey = 0;
		
		System.out.print("숫자를 입력하세요 :");
		pey = scanner.nextInt();
		String message = "";
		
		if(pey % 2 == 0) {
			message = "짝수";
		}else if (pey % 1 == 0) {
			message = "홀수";
		}
		
		
		
		System.out.println("입력하신 숫자" + pey + "(은)는" + message + "입니다.");
		
		
		
	}

}
