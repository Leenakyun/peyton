package com.javalce.base;

import java.util.Scanner;

public class Main_02 {
	public static void main(String[] args) {
		
		// Declare
		Scanner scanner = new Scanner(System.in);
		int price = 0;     // 사용자 금액 입력
		String message = "";   // 출력값 멘
		
		// Input
		System.err.print("금액을 입력하세요! :");
		price = scanner.nextInt();
		
		
		// Process
		if(price >= 8000) {
			message = "너무 비쌉니다.";
		}else if(price >= 5000) {
			message = "조금 비쌉니다.";
		}else if(price >= 3000) {
			message = "적당한 금액 입니다.";
		}else {
			message = "싼 가격입니다.";
		}
		
		
		// Output
		System.out.println(message);
		
		
		
		
	}
}
