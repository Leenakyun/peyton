package com.javalec.base;

import com.javalec.function.SumEvenOdd;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//1~10까지의 합계를 구하고 그합이 짝수 인지 홀수인지 판별
	/*	int sum =0;
		
		for(int i=0; i<=10; i++) {                       이런 수식은 안됨. 
			sum += i;
		}
		System.out.println()"1~10 까지의 합은?" + sum);
		
		if(sum % 2 == 0) {
			System.out.println("짝수");
		}else {
			System.out.println("홀수");
		}
		*/
		
		SumEvenOdd sumEvenOdd = new SumEvenOdd();
		
		int result = sumEvenOdd.sumCalc(1, 10);
		
		System.out.println("1부터 10까지의 합계는 " + result);
		
		result = sumEvenOdd.sumCalc(100, 1000);
		
		System.out.println("100부터 1000까지의 합계는 " + result);
		
		
		
		
		
		
		
		
		
	}

}
