package com.javalce.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		/*
		 * 예제
		 * 숫자를 입력 받아 아래와 같이 출력 되는 프로그램을 만들어 보자
		 * 입력받은 수가 양수 일때 짝수 이면 "짝수" 출력
		 * 홀수 이면 "홀수"가 출력
		 * 음수이면 "음수". 0이면 "0"으로 출력 해보자
		 * 
		 * 실행 될때
		 * 숫자를 입력하세요 :
		 * 숫자 :
		 * -- 입니다.
		 */

		
		// 선언문 
		
		Scanner scanner = new Scanner(System.in);
		
		int scr = 0;
		
		System.out.println("숫자를 입력하세요 :");
		scr = scanner.nextInt();
		
		String message = "";
		
		
		
		
		// 입력문 
		
				
		if(scr % 2) {
			System.out.println("짝수");
		}
		if(scr % 1){
			System.out.println("홀수");
		}
		
		
		
		
		
		//  출력문 
		
		System.out.println(message + "입니다.");
		
		
		
		
		
		
	}

}
