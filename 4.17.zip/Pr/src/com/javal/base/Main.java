package com.javal.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 선언 
		
		Scanner scanner = new Scanner(System.in);
		int kr = 0, eg = 0, ms = 0, tot = kr + eg + ms;
		double avg = tot / 3;
		
		String message = "";
		
		
		
		
		
		
		
		// 입력 부분 
		
		System.out.print("국어점수를 입력하세요 :");
		kr = scanner.nextInt();
		System.out.print("영어점수를 입력하세요 :");
		eg = scanner.nextInt();
		System.out.print("수학점수를 입력하세요 :");
		ms = scanner.nextInt();
		
		
		if(kr > 100 || kr < 0) {
			System.out.println("다시 입력하세요.");
		}
		if(eg > 100 || eg < 0) {
			System.out.println("다시 입력하세요.");
		}
		if(ms > 100 || ms < 0) {
			System.out.println("다시 입력하세요.");
		}
		
		if(kr > avg) {
			message = "평균 보다 높습니다.";
			
		} else if(kr < avg) {
			message = "";
		}
		if(eg > avg) {
			message = "평균 입니다.";
		}else if(eg < avg) {
			message = "";
		}
		if(ms > avg) {
			message = "평균 보다 낮습니다.";
		}else if(ms < avg) {
			message = "";
		}
		
		
		
		//출력 부분 
		
		message = "평균 점수";
		message = "국어 점수는 평균 보다 높습니다.";
		message = "영어 점수는 평균 입니다.";
		message = "수학 점수는 평균 보다 낮습니다.";
		
		
		
		
	}

}
