package com.javalce.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * 홀수 짝수 만들기 
		 * 
		 */
		
		
		// 선언문
		
		Scanner scanner = new Scanner(System.in);
		
				
		int scr = 0;
		
		System.out.println("숫자를 입력 해주세요 :");
		scr = scanner.nextInt();
		String message = "";
		
		//  입력문 
		
		if(scr % 2 == 0) {
			System.out.println("짝수");
		}else if(scr % 1 == 0) {
			System.out.println("홀수");
		
		}
		
		
		//  출력문 
		
		System.out.println(message + "입니다.");
		
		
		
		
		
		
		
		
		
		
	}

}
