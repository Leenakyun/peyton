package com.javalec.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// 사용자가 입력한 숫자로 구구단을 구성. 
		
	/*	
		Scanner scanner = new Scanner(System.in);
		
		int dan = 0;
		
		
		System.out.println("구구단 몇단 :");
		dan = scanner.nextInt();
		
		
		//
		
		for(int i=1; i<=9; i++) {
			System.out.println(dan + "x" + i + "=" +(dan*i));
		}
		*/

	/*	
		
		// 구구단 전체 출력 
		
		
		for(int dan=2; dan<=9; dan++) {
			System.out.println("------" + dan + "단 ------");
			for(int num = 1; num <= 9; num++) {
				System.out.println(dan + "x" + num + "=" + (dan*num));
			}
		}
		
		*/
		
	/*	
		// 구구단 전체 출력중 곱해지는 수가 짝수인 경우에만 출력하기 
		
		Scanner scanner = new Scanner(System.in);
		
		
		
		System.out.println();
		
		
		
		for(int dan=2; dan<=9; dan++) {
			System.out.println("---" + dan + "단 ---");
			for(int num = 1; num<=9; num++) {
				if(num % 2 == 0)
				System.out.println(dan + "x" + num + "=" + (dan*num));
			}
		}
		
	*/	
	
	/*	
		// 구구단 전체 출력중 짝수단과 곱해지는 수가 짝수인 경우에만 출력하기 
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println();
		
		
		for(int dan=2; dan<=9; dan++) {
			if(dan % 2 == 0) {
			System.out.println("---" + dan + "단 ---");
			for(int num = 1; num<=9; num++) {
				if(num % 2 == 0)
				System.out.println(dan + "x" + num + "=" + (dan*num));
				}
			}
		}
		
	*/	
	
	/*	
		// 구구단 전체 출력중 곱해지는 수가 홀수인 경우에는 곱해지는 수를 * 로 표시하기 
		
        Scanner scanner = new Scanner(System.in);
		
		System.out.println();
		
		
		for(int dan=2; dan<=9; dan++) {
			for(int num = 1; num<=9; num++)
					System.out.println(dan + "x" + (num % 2 == 0 ? num : "*") + "=" + (dan*num));
				}
	*/				
			
	// 구구단들이 일자가 아닌 옆으로 나오도록 만들어보기 		
		
        Scanner scanner = new Scanner(System.in);
		
		System.out.println();
		/*
			for(int num = 1; num <= 9; num++) {
				for(int dan = 2; dan <= 9; dan++) {
					System.out.print(dan +"x" + num + "=" + (dan*num) + "\t");
				
			}
			System.out.println();
		}
	*/
	
	/*	
		// 짝수만 나오게 만들기. 	 num의 증가값을 변경하면 빠르게 짝수로만 나온다.
			for(int num = 2; num <= 9; num+= 2){
				for(int dan = 2; dan <= 9; dan++) {
					System.out.print(dan +"x" + num + "=" + (dan*num) + "\t");
				
			}
			System.out.println();
		}
	
	*/
	
		
/*		
	// 홀수의 값을 *로 표기하기 & 입력값 문자열 정리하기.    (string.format 는 글자 정렬할때 사용)
		
			
			
			for(int num = 1; num <= 9; num++){
				for(int dan = 2; dan <= 9; dan++) {
					System.out.print(dan +"x" + (num % 2 == 0 ? num : "*") + "=" + String.format("%2d", dan*num) + "\t");
			}   // String.format("%2d", 들어가야하는 문자 및 숫자)  %2는 2칸을 띄운다는 뜻이고 d는 (들어가야하는 문자 및 숫자의 값)을 뜻한다.
			
			System.out.println();
		}
	
	*/
		
		// 구구단을 전체 나오게 하지만 홀수는 8까지만 나오게 만들기. (짝수 값만 나오게 하기.)
	
		for(int num = 1; num <= 9; num++){
			for(int dan = 2; dan <= 9; dan++){		
				System.out.print(((dan*num) % 2 == 1)? "\t\t" : (dan + "x" + num + "=" + (dan*num) + "\t"));
			
			} System.out.println();
					}
		
		
		
		
		
		
		}
			
	}


