package com.javalce.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * 실행 화면)
		 * 점수를 입력하세요 : 89
		 * 
		 * 점수가 89 여서 B학점 입니다.
		 */
		
		
		
		
		
		// 선언문
		
		Scanner scanner = new Scanner(System.in);
		int scr = 0;
		
		System.out.print("점수를 입력 하세요 :");
		
		String message = "";
		
		scr = scanner.nextInt();		
		 
		
		
		
		
		
		
		// 입력값 
		
		if(scr >= 90) {
			message = ("A학점");
		}else if(scr > 80 || scr < 70) {
			message = ("B학점");
		}else if(scr > 70 || scr < 60) {
			message = ("C학점");
		}else if(scr > 60 || scr < 50) {
			message = ("D학점");
		}else {
			message = ("F학점");
		}
		
		
		
		
		
		// 출력값 
		
		System.out.println("점수가 " + scr + "여서" + message + "입니다.");
		
		
		
		
		
		
		
		
	}

}
