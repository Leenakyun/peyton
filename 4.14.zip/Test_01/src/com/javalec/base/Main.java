package com.javalec.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		// 입력한 숫자부터 4개를 증가하여 화면 가로로 구구단을 표시하기.( 오른쪽 정렬 ) 
		/*
		 * input your number : 4
		 * 4 x 1 = 4    5 x 1 = 5    6 x 1 = 6    7 x 7 = 7
		 * 
		 */

		
		
		// 위의 문제를 역순으로 나오게 작업하기. 
		
		
		
		// 10의 10^ ~ 10의 10승 까지 제곱승을 구하라.    누적값을 적용하면됨 
		/*
		 * 10^ 0 = 1
		 * 10^ 1 = 10
		 * 10^ 2 = 100             정렬은 오른쪽차순으로 하여라.
		 * 10^ 3 = 1000
		 * 10^ 4 = 10000
		 * 10^ 5 = 100000
		 * 10^ 6 = 1000000
		 * 10^ 7 = 10000000
		 * 10^ 8 = 100000000
		 * 10^ 9 = 1000000000
		 * 10^ 10 = 10000000000
		 */
		
		
		// 해답 
/*
		double x = 1;
		
		
		for(int i=0; i<=10; i++)
			System.out.println("10^" + String.format("%2d", i) + "=" + String.format("%12.0f", x));{   // 0.f는 뒷자리 숫자를 전부 표기하겠다는 내용이다. 
			x = x * 10;
			}
		
		*/
		
		/* 입력한 숫자 만큼 별 모양이 증가하면서 출력하다가 다시 감소하면서 출력하기
		 * input your decimal no. : 5
		 * *
		 * **
		 * ***
		 * ****
		 * *****
		 * ****
		 * ***
		 * **
		 * *  
		 */
		
		
		// 해답 
		
	/*	
		int inputValue = 5;
		
		
		// 증가 
		
		for(int i=1; i<=inputValue; i++) {
			for(int j=1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	*/	
/*		
		// 감소
		
		for(int i = inputValue -1; i>= 0; i--) {
			for(int j = 1; j <= i; j++) {
				System.out.println("*");
			}
			System.out.println();
		}
*/		
		
		/*
		 * 입력한 수의 factorial 구하기 (예: 4! = x3x2x1) 
		 * input your decimal no. : 4
		 * 4's factorial value = 24
		 */
		
		
		
		
		/*
		 * 숫자 삼각형에 프로그램 작성.
		 * 몇 단의 파라미드로 구성할까 ? 5
		 * 1
		 * 2 3
		 * 4 5 6
		 * 7 8 9 10
		 * 11 12 13 14 15
		 * 
		 */
		
		
		/*
		 * 더하기 할 숫자들의 개수를 정한 후 숫자를 입력 받아서 입력한 숫자의 합을 구하는 프로그램 작성.
		 * 몇개의 숫자를 더할까요? : 4
		 * 4개의 숫자를 입력하세요
		 * 1
		 * 2
		 * 3
		 * 4
		 * 입력한 숫자의 합은 10 입니다.
		 */
		
		
		/*
		 * 몇 개의 숫자를 입력할지 결정한 후 숫자를 입력하고 이중 최대값의 위치와 최대값을 구하라.
		 * 
		 * 입력할 숫자의 갯수 ? (100개 미만) : 5
		 * 5개의 숫자를 입력하세요!
		 * 11
		 * 12
		 * 13
		 * 14
		 * 15
		 * 입력한 숫자중 최대값은 15이고 5번째 값 입니다.
		 * 
		 */
	
		
		
		/*
		 * 입력한 한 자릿수 정수의 합을 구하는프로그램을 작성하라.
		 * Enter an integer(0~9) : 12345678
		 * Sum of digits = 36
		 */
		
	/*    해답 
		
		Scanner scanner = new Scanner(System.in);
		
		int inputValue = 0;
		int calcValue = 0;
		int remainder = 0;  // 나머지값 
		int sum = 0;        // 합계 
		System.out.println("Enter an integer(0~9) :");
		inputValue = scanner.nextInt();
		 
		calcValue = inputValue;
		
		while(calcValue != 0) {
			remainder = calcValue % 10;
			sum += remainder;
			calcValue = calcValue / 10;
		}
		System.out.println("Sum of digits =" + sum);
*/	
		
		/*
		 * 학생수가 4명이고 과목이 3과목일 경우의 점수 합계와 평균 구하기 기능 추가
		 * Korean의 성적을 입력 :
		 * No1의 성적은 :
		 * No2의 성적은 :
		 * No3의 성적은 :
		 * No4의 성적은 : 
		 * English의 성적을 입력 :
		 * No1의 성적은 :
		 * No2의 성적은 :
		 * No3의 성적은 :
		 * No4의 성적은 :
		 * Mathematics의 성적을 입력 :
		 * No1의 성적은 :
		 * No2의 성적은 :
		 * No3의 성적은 :
		 * No4의 성적은 :
		 *      Korean          English        Mathematics       Total      Average
		 * No1    11              11               11             33          11
		 * No2    12              12               12             36          12
		 * No3    13              13               13             39          13
		 * No4    14              14               14             42          14
		 */
		
		
		
		
		
	}

}
