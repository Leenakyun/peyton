package com.javalec.util;

public class ShareVar {


//		public static final String DBName = "jdbc:mysql://127.0.0.1/sunshine?serverTimezone=UTC&characterEncoding=utf8&useSSL=FALSE";
		/* 팀장 IP */
		public static final String DBName = "jdbc:mysql://127.0.0.1/sunshine?serverTimezone=UTC&characterEncoding=utf8&useSSL=FALSE";
		/* DB 계정 */
		public static final String DBUser = "root";
		/* DB 비밀번호 */
		public static final String DBPass = "qwer1234";
		/* File */
		public static String userid = "donghyun";
	
}
