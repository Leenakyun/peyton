package com.javalec.function;

public class JLabelSetting {

	
	
}
