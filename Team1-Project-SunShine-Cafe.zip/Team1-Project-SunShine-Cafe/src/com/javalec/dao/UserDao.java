package com.javalec.dao;

public class UserDao {

}
