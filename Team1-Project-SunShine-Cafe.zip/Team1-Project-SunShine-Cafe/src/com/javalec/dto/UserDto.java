package com.javalec.dto;

public class UserDto {

}
